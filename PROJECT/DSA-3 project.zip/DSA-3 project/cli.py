#!/usr/bin/env python3
"""
Source Code Clone Detector - Command Line Interface (CLI)
Provides fast terminal operations for direct file comparisons, codebase scans,
benchmark verification, and database history viewing.
"""

import sys
import os
import argparse
from pathlib import Path
from typing import List, Dict

# Ensure project root is in sys.path
BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

from backend.core import (
    Tokenizer, Normalizer, RabinKarpHasher,
    CloneDetector, CloneType, CloneClusterer, RefactoringEngine,
    generate_html_visual_report
)
from backend.database import init_db, save_scan, get_recent_scans, get_scan_details, get_db_stats

# Terminal ANSI color helpers
class Colors:
    HEADER = "\033[95m"
    BLUE = "\033[94m"
    CYAN = "\033[96m"
    GREEN = "\033[92m"
    WARNING = "\033[93m"
    FAIL = "\033[91m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    END = "\033[0m"

def print_banner():
    print(f"""{Colors.CYAN}{Colors.BOLD}
========================================================================
   SOURCE CODE CLONE DETECTOR | DSA-3 PROJECT (25CS1302E)
   Guide: Dr. Dyuti Banerjee | Team: V. Nikith, T. Harsha, D. Satvarsh
========================================================================{Colors.END}""")

def cmd_compare(args):
    path_a = Path(args.file_a)
    path_b = Path(args.file_b)

    if not path_a.is_file() or not path_b.is_file():
        print(f"{Colors.FAIL}Error: Both files must exist.{Colors.END}")
        sys.exit(1)

    with open(path_a, "r", encoding="utf-8") as fa, open(path_b, "r", encoding="utf-8") as fb:
        code_a = fa.read()
        code_b = fb.read()

    lang = args.lang or Tokenizer.detect_language(str(path_a))
    threshold = args.threshold / 100.0

    print(f"{Colors.BOLD}Comparing:{Colors.END} {path_a.name} vs {path_b.name}")
    print(f"{Colors.DIM}Language: {lang} | Window: {args.window} | Threshold: {args.threshold}%{Colors.END}\n")

    detector = CloneDetector(window_size=args.window, similarity_threshold=threshold)
    result = detector.compare_two_snippets(code_a, code_b, language=lang, threshold=threshold)

    # Colorize Verdict
    ctype = result["clone_type"]
    if "Type-1" in ctype:
        color = Colors.GREEN
    elif "Type-2" in ctype:
        color = Colors.BLUE
    elif "Type-3" in ctype:
        color = Colors.WARNING
    else:
        color = Colors.FAIL

    print(f"{Colors.BOLD}Detection Verdict:{Colors.END} {color}{Colors.BOLD}{ctype}{Colors.END}")
    print(f"{Colors.BOLD}Similarity Score:{Colors.END}  {result['similarity']}%")
    print(f"{Colors.BOLD}Execution Time:{Colors.END}    {result['execution_time_ms']} ms")
    print(f"{Colors.BOLD}Tokens Analyzed:{Colors.END}   {result.get('token_count', 0)}")
    print(f"\n{Colors.BOLD}Explanation:{Colors.END}\n  {result['explanation']}")

    if result.get("is_clone"):
        refactor = RefactoringEngine.generate_refactoring({
            "clone_type": ctype,
            "fragment_a": {"file_path": str(path_a), "start_line": 1, "end_line": len(code_a.splitlines()), "code_snippet": code_a},
            "fragment_b": {"file_path": str(path_b), "start_line": 1, "end_line": len(code_b.splitlines()), "code_snippet": code_b}
        })
        print(f"\n{Colors.GREEN}{Colors.BOLD}[Suggested Refactoring]{Colors.END} {refactor['title']}")
        print(f"{Colors.DIM}Strategy: {refactor['strategy']}{Colors.END}")

    if args.save:
        scan_info = {
            "scan_name": f"CLI Compare: {path_a.name} vs {path_b.name}",
            "scan_type": "snippet",
            "language": lang,
            "total_files": 2,
            "total_lines": len(code_a.splitlines()) + len(code_b.splitlines()),
            "cloned_files_count": 2 if result.get("is_clone") else 0,
            "cloned_lines_count": len(code_a.splitlines()) + len(code_b.splitlines()) if result.get("is_clone") else 0,
            "duplication_percentage": result.get("similarity", 0.0) if result.get("is_clone") else 0.0,
            "execution_time_ms": result.get("execution_time_ms", 0.0),
            "clone_breakdown": {ctype: 1 if result.get("is_clone") else 0}
        }
        pair_rec = [{
            "clone_type": ctype,
            "similarity": result["similarity"],
            "token_count": result.get("token_count", 0),
            "fragment_a": {"file_path": str(path_a), "start_line": 1, "end_line": len(code_a.splitlines()), "code_snippet": code_a},
            "fragment_b": {"file_path": str(path_b), "start_line": 1, "end_line": len(code_b.splitlines()), "code_snippet": code_b},
            "refactoring_suggestion": result.get("refactoring_suggestion", "")
        }]
        saved_id = save_scan(scan_info, pair_rec)
        print(f"\n{Colors.DIM}[SQLite] Scan saved with ID #{saved_id}{Colors.END}")

    if args.report:
        rep_data = {
            "scan_name": f"Compare: {path_a.name} vs {path_b.name}",
            "scan_type": "snippet",
            "language": lang,
            "total_files": 2,
            "total_lines": len(code_a.splitlines()) + len(code_b.splitlines()),
            "cloned_files_count": 2 if result.get("is_clone") else 0,
            "cloned_lines_count": len(code_a.splitlines()) + len(code_b.splitlines()) if result.get("is_clone") else 0,
            "duplication_percentage": result.get("similarity", 0.0) if result.get("is_clone") else 0.0,
            "execution_time_ms": result.get("execution_time_ms", 0.0),
            "clone_breakdown": {ctype: 1 if result.get("is_clone") else 0},
            "clone_pairs": [{
                "clone_type": ctype,
                "similarity": result["similarity"],
                "token_count": result.get("token_count", 0),
                "fragment_a": {"file_path": str(path_a), "start_line": 1, "end_line": len(code_a.splitlines()), "code_snippet": code_a},
                "fragment_b": {"file_path": str(path_b), "start_line": 1, "end_line": len(code_b.splitlines()), "code_snippet": code_b},
                "refactoring_suggestion": result.get("refactoring_suggestion", "")
            }]
        }
        html_out = generate_html_visual_report(rep_data)
        out_file = Path(args.report).resolve()
        with open(out_file, "w", encoding="utf-8") as f:
            f.write(html_out)
        print(f"{Colors.GREEN}{Colors.BOLD}Visual Report Saved:{Colors.END} {out_file}")

def cmd_scan(args):
    target_path = Path(args.target)
    file_contents: Dict[str, str] = {}

    if target_path.is_dir():
        valid_exts = {".py", ".java", ".cpp", ".c", ".h", ".hpp", ".js"}
        for root, _, files in os.walk(target_path):
            for f in files:
                if any(f.endswith(ext) for ext in valid_exts):
                    p = Path(root) / f
                    try:
                        with open(p, "r", encoding="utf-8") as fp:
                            file_contents[str(p.relative_to(target_path.parent))] = fp.read()
                    except Exception:
                        pass
    else:
        print(f"{Colors.FAIL}Error: Target path must be a directory.{Colors.END}")
        sys.exit(1)

    if len(file_contents) < 2:
        print(f"{Colors.FAIL}Error: Found less than 2 source files in directory.{Colors.END}")
        sys.exit(1)

    threshold = args.threshold / 100.0
    print(f"{Colors.BOLD}Scanning repository directory:{Colors.END} {target_path}")
    print(f"{Colors.DIM}Found {len(file_contents)} files to index and hash...{Colors.END}\n")

    detector = CloneDetector(window_size=args.window, similarity_threshold=threshold)
    res = detector.scan_files(file_contents, threshold=threshold)
    clusters = CloneClusterer.build_clusters(res["clone_pairs"])

    print(f"{Colors.BOLD}=== SCAN SUMMARY ==={Colors.END}")
    print(f"Total Files Scanned:       {res['total_files']}")
    print(f"Total Lines of Code:       {res['total_lines']}")
    print(f"Cloned Lines:              {res['cloned_lines_count']} lines")
    print(f"{Colors.BOLD}Duplication Percentage:    {Colors.FAIL if res['duplication_percentage'] > 30 else Colors.GREEN}{res['duplication_percentage']}%{Colors.END}")
    print(f"Clone Pairs Detected:      {res['clone_pairs_count']}")
    print(f"DSU Clone Classes:         {len(clusters)}")
    print(f"Scan Execution Time:       {res['execution_time_ms']} ms")

    b = res["clone_breakdown"]
    print(f"\n{Colors.BOLD}Clone Type Breakdown:{Colors.END}")
    print(f"  Type-1 (Exact):          {b.get('Type-1', 0)}")
    print(f"  Type-2 (Renamed):        {b.get('Type-2', 0)}")
    print(f"  Type-3 (Near-Miss):      {b.get('Type-3', 0)}")

    if clusters:
        print(f"\n{Colors.BOLD}=== DSU CLONE CLASSES (Equivalence Groups) ==={Colors.END}")
        for c in clusters:
            print(f"  {Colors.CYAN}{Colors.BOLD}{c['cluster_id']}{Colors.END} ({c['member_count']} locations, avg {c['average_lines']} lines):")
            for frag in c["fragments"]:
                print(f"    - {frag['file_path']} (L{frag['start_line']}-L{frag['end_line']})")

    if args.save:
        scan_info = {
            "scan_name": f"CLI Scan: {target_path.name}",
            "scan_type": "multi-file",
            "language": "multi",
            "total_files": res["total_files"],
            "total_lines": res["total_lines"],
            "cloned_files_count": res["cloned_files_count"],
            "cloned_lines_count": res["cloned_lines_count"],
            "duplication_percentage": res["duplication_percentage"],
            "execution_time_ms": res["execution_time_ms"],
            "clone_breakdown": res["clone_breakdown"]
        }
        saved_id = save_scan(scan_info, res["clone_pairs"], clusters)
        print(f"\n{Colors.DIM}[SQLite] Scan saved with ID #{saved_id}{Colors.END}")

    if args.report:
        report_data = {
            "scan_name": f"Directory Scan: {target_path.name}",
            "scan_type": "multi-file",
            "language": "multi",
            "total_files": res["total_files"],
            "total_lines": res["total_lines"],
            "cloned_files_count": res["cloned_files_count"],
            "cloned_lines_count": res["cloned_lines_count"],
            "duplication_percentage": res["duplication_percentage"],
            "execution_time_ms": res["execution_time_ms"],
            "clone_breakdown": res["clone_breakdown"],
            "clone_pairs": res["clone_pairs"],
            "clusters": clusters
        }
        html_out = generate_html_visual_report(report_data, title=f"Scan Report - {target_path.name}")
        out_file = Path(args.report).resolve()
        with open(out_file, "w", encoding="utf-8") as f:
            f.write(html_out)
        print(f"{Colors.GREEN}{Colors.BOLD}Visual Report Saved:{Colors.END} {out_file}")

def cmd_report(args):
    init_db()
    details = get_scan_details(args.scan_id)
    if not details:
        print(f"{Colors.FAIL}Error: Scan ID #{args.scan_id} not found in database.{Colors.END}")
        sys.exit(1)

    out_file = Path(args.output).resolve()
    html_out = generate_html_visual_report(details, title=f"Clone Audit Report #{args.scan_id} - {details.get('scan_name', '')}")
    with open(out_file, "w", encoding="utf-8") as f:
        f.write(html_out)
    print(f"{Colors.GREEN}{Colors.BOLD}Visual Report Generated Successfully:{Colors.END} {out_file}")

def cmd_history(args):
    init_db()
    scans = get_recent_scans(limit=args.limit)
    stats = get_db_stats()

    print(f"{Colors.BOLD}=== SQLITE SCAN HISTORY ({stats.get('total_scans', 0)} total) ==={Colors.END}\n")
    if not scans:
        print("No scan records found in database.")
        return

    print(f"{'ID':<6} {'Scan Name':<32} {'Type':<12} {'Files':<8} {'Dupl %':<10} {'Pairs':<8} {'Date':<20}")
    print("-" * 100)
    for s in scans:
        print(f"#{s['id']:<5} {s['scan_name'][:30]:<32} {s['scan_type']:<12} {s['total_files']:<8} {s['duplication_percentage']:<9}% {s['clone_pairs_count']:<8} {s['created_at']:<20}")

def cmd_test(args):
    import unittest
    suite = unittest.defaultTestLoader.discover(str(BASE_DIR / "tests"), pattern="test_*.py")
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)

def main():
    print_banner()
    parser = argparse.ArgumentParser(description="Source Code Clone Detector CLI")
    subparsers = parser.add_subparsers(dest="command", help="Available sub-commands")

    # compare
    p_comp = subparsers.add_parser("compare", help="Compare two code files directly")
    p_comp.add_argument("file_a", help="Path to first code file")
    p_comp.add_argument("file_b", help="Path to second code file")
    p_comp.add_argument("--lang", default=None, help="Language override")
    p_comp.add_argument("--window", type=int, default=15, help="Window size for rolling hash")
    p_comp.add_argument("--threshold", type=float, default=50.0, help="Similarity threshold percentage (e.g. 50)")
    p_comp.add_argument("--save", action="store_true", default=True, help="Save result to SQLite")
    p_comp.add_argument("-r", "--report", default=None, help="Output path for standalone HTML visual report (e.g. report.html)")

    # scan
    p_scan = subparsers.add_parser("scan", help="Scan a directory for clones across all files")
    p_scan.add_argument("target", help="Directory path to scan")
    p_scan.add_argument("--window", type=int, default=15, help="Window size")
    p_scan.add_argument("--threshold", type=float, default=50.0, help="Similarity threshold percentage")
    p_scan.add_argument("--save", action="store_true", default=True, help="Save to SQLite")
    p_scan.add_argument("-r", "--report", default=None, help="Output path for standalone HTML visual report (e.g. report.html)")

    # report
    p_rep = subparsers.add_parser("report", help="Generate standalone HTML visual report for a saved scan")
    p_rep.add_argument("scan_id", type=int, help="Scan ID from SQLite database")
    p_rep.add_argument("-o", "--output", default="report.html", help="Output file path (default: report.html)")

    # history
    p_hist = subparsers.add_parser("history", help="List past scans from SQLite database")
    p_hist.add_argument("--limit", type=int, default=15, help="Number of records to show")

    # test
    subparsers.add_parser("test", help="Run automated test suite")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(0)

    if args.command == "compare":
        cmd_compare(args)
    elif args.command == "scan":
        cmd_scan(args)
    elif args.command == "report":
        cmd_report(args)
    elif args.command == "history":
        cmd_history(args)
    elif args.command == "test":
        cmd_test(args)

if __name__ == "__main__":
    main()
