"""
Rabin-Karp Rolling Hash Algorithm and Sliding Window Generator.
Provides efficient O(N) token sequence hashing for inverted index lookups.
"""

from typing import List, Tuple, Dict, Any

class RabinKarpHasher:
    # Mersenne prime for large modulus with 64-bit precision, minimal collisions
    MODULUS = 2305843009213693951  # 2^61 - 1
    BASE = 1000003

    def __init__(self, window_size: int = 20):
        self.k = window_size
        # Precompute Base^(k-1) % MODULUS
        self.base_pow = pow(self.BASE, self.k - 1, self.MODULUS)

    def _token_val(self, token_str: str) -> int:
        """Hash string token to integer value for polynomial rolling."""
        return hash(token_str) & 0xFFFFFFFF

    def compute_hashes(self, token_stream: List[str]) -> List[Tuple[int, int, int]]:
        """
        Computes rolling hashes for each sliding window of size k.
        Returns:
            List of tuples: (hash_value, start_index, end_index)
            where end_index is exclusive.
        """
        n = len(token_stream)
        if n < self.k:
            return []

        results = []
        current_hash = 0

        # Compute initial window hash
        for i in range(self.k):
            val = self._token_val(token_stream[i])
            current_hash = (current_hash * self.BASE + val) % self.MODULUS

        results.append((current_hash, 0, self.k))

        # Slide the window
        for i in range(1, n - self.k + 1):
            outgoing_val = self._token_val(token_stream[i - 1])
            incoming_val = self._token_val(token_stream[i + self.k - 1])

            # Remove outgoing token component
            current_hash = (current_hash - (outgoing_val * self.base_pow) % self.MODULUS) % self.MODULUS
            if current_hash < 0:
                current_hash += self.MODULUS

            # Shift left and add incoming token
            current_hash = (current_hash * self.BASE + incoming_val) % self.MODULUS

            results.append((current_hash, i, i + self.k))

        return results
