"""
Disjoint Set Union (DSU) for Clone Clustering.
Clusters interconnected clone pairs into Clone Classes / Clusters.
"""

from typing import List, Dict, Any, Set
from collections import defaultdict

class DisjointSetUnion:
    def __init__(self):
        self.parent = {}
        self.rank = {}

    def find(self, item: str) -> str:
        if item not in self.parent:
            self.parent[item] = item
            self.rank[item] = 0
            return item
        if self.parent[item] != item:
            self.parent[item] = self.find(self.parent[item])  # Path compression
        return self.parent[item]

    def union(self, item1: str, item2: str):
        root1 = self.find(item1)
        root2 = self.find(item2)

        if root1 != root2:
            # Union by rank
            if self.rank[root1] < self.rank[root2]:
                self.parent[root1] = root2
            elif self.rank[root1] > self.rank[root2]:
                self.parent[root2] = root1
            else:
                self.parent[root2] = root1
                self.rank[root1] += 1

class CloneClusterer:
    @staticmethod
    def build_clusters(clone_pairs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Groups clone pairs into distinct Clone Classes using Disjoint Set Union.
        """
        dsu = DisjointSetUnion()
        fragment_details: Dict[str, Dict[str, Any]] = {}

        for pair in clone_pairs:
            frag_a = pair["fragment_a"]
            frag_b = pair["fragment_b"]

            key_a = f"{frag_a['file_path']}:{frag_a['start_line']}-{frag_a['end_line']}"
            key_b = f"{frag_b['file_path']}:{frag_b['start_line']}-{frag_b['end_line']}"

            fragment_details[key_a] = frag_a
            fragment_details[key_b] = frag_b

            dsu.union(key_a, key_b)

        # Collect components
        groups = defaultdict(list)
        for key in fragment_details:
            root = dsu.find(key)
            groups[root].append(fragment_details[key])

        # Convert to structured clusters
        clusters = []
        cluster_idx = 1
        for root, fragments in groups.items():
            if len(fragments) < 2:
                continue

            # Determine dominant clone type and average lines
            total_lines = sum(f.get("line_count", 1) for f in fragments)
            avg_lines = round(total_lines / len(fragments), 1)

            clusters.append({
                "cluster_id": f"Cluster-{cluster_idx:02d}",
                "member_count": len(fragments),
                "average_lines": avg_lines,
                "fragments": fragments,
                "summary": f"Detected across {len(fragments)} code locations"
            })
            cluster_idx += 1

        clusters.sort(key=lambda c: c["member_count"], reverse=True)
        return clusters
