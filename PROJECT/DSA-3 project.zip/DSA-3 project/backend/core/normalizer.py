"""
Normalizer for Source Clone Detection.
Provides Type-1 (Exact Token Representation) and
Type-2 (Parameterized / Renamed Identifier Representation).
"""

from typing import List, Dict, Tuple
from .tokenizer import Token, TokenType

class Normalizer:
    @staticmethod
    def normalize_type1(tokens: List[Token]) -> List[str]:
        """
        Type-1 normalization:
        Retains exact token values (syntax/operators/keywords/identifiers),
        ignoring whitespace and comments.
        """
        return [tok.value for tok in tokens]

    @staticmethod
    def normalize_type2(tokens: List[Token]) -> Tuple[List[str], Dict[str, str]]:
        """
        Type-2 normalization:
        Normalizes variable and function identifiers to $VAR_1, $VAR_2, etc.,
        and literals to $VAL, while keeping language keywords and operators unchanged.
        Returns:
            normalized_tokens: List of normalized token strings
            identifier_map: Mapping from original identifier to parameter tag
        """
        normalized: List[str] = []
        identifier_map: Dict[str, str] = {}
        id_counter = 0

        for tok in tokens:
            if tok.type == TokenType.IDENTIFIER:
                if tok.value not in identifier_map:
                    id_counter += 1
                    identifier_map[tok.value] = f"$VAR_{id_counter}"
                normalized.append(identifier_map[tok.value])
            elif tok.type == TokenType.LITERAL_NUMBER:
                normalized.append("$NUM")
            elif tok.type == TokenType.LITERAL_STRING:
                normalized.append("$STR")
            else:
                # KEYWORD, OPERATOR, DELIMITER remain exact
                normalized.append(tok.value)

        return normalized, identifier_map
