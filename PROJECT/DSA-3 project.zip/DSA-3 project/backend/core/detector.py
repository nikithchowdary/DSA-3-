"""
Core Clone Detection Engine.
Detects Type-1, Type-2, and Type-3 clones using Rabin-Karp indexing,
token normalization, sequence extension, and similarity metrics.
"""

import difflib
import time
from typing import List, Dict, Any, Tuple, Optional
from collections import defaultdict

from .tokenizer import Tokenizer, Token, TokenType
from .normalizer import Normalizer
from .rabin_karp import RabinKarpHasher

class CloneType:
    TYPE_1 = "Type-1 (Exact)"
    TYPE_2 = "Type-2 (Renamed)"
    TYPE_3 = "Type-3 (Near-Miss)"
    NON_CLONE = "Non-Clone"

class CloneFragment:
    def __init__(self, file_id: str, file_path: str, start_line: int, end_line: int,
                 start_token_idx: int, end_token_idx: int, code_snippet: str):
        self.file_id = file_id
        self.file_path = file_path
        self.start_line = start_line
        self.end_line = end_line
        self.start_token_idx = start_token_idx
        self.end_token_idx = end_token_idx
        self.code_snippet = code_snippet

    def to_dict(self):
        return {
            "file_id": self.file_id,
            "file_path": self.file_path,
            "start_line": self.start_line,
            "end_line": self.end_line,
            "line_count": max(1, self.end_line - self.start_line + 1),
            "code_snippet": self.code_snippet
        }

class ClonePair:
    def __init__(self, fragment_a: CloneFragment, fragment_b: CloneFragment,
                 clone_type: str, similarity: float, token_count: int,
                 refactoring_suggestion: str = ""):
        self.fragment_a = fragment_a
        self.fragment_b = fragment_b
        self.clone_type = clone_type
        self.similarity = round(similarity, 2)
        self.token_count = token_count
        self.refactoring_suggestion = refactoring_suggestion

    def to_dict(self):
        return {
            "fragment_a": self.fragment_a.to_dict(),
            "fragment_b": self.fragment_b.to_dict(),
            "clone_type": self.clone_type,
            "similarity": self.similarity,
            "token_count": self.token_count,
            "refactoring_suggestion": self.refactoring_suggestion
        }

class CloneDetector:
    def __init__(self, window_size: int = 15, similarity_threshold: float = 0.50):
        self.window_size = window_size
        self.similarity_threshold = similarity_threshold
        self.hasher = RabinKarpHasher(window_size=self.window_size)

    def _extract_lines(self, source_code: str, start_line: int, end_line: int) -> str:
        lines = source_code.splitlines()
        s_idx = max(0, start_line - 1)
        e_idx = min(len(lines), end_line)
        return "\n".join(lines[s_idx:e_idx])

    def _is_type2_structural_match(self, tokens_a: List[Token], tokens_b: List[Token]) -> bool:
        """
        Verifies if two token sequences have identical syntactic structure (same keywords,
        operators, delimiters in the exact same positions), with variations only in identifiers or literals.
        """
        if len(tokens_a) != len(tokens_b) or len(tokens_a) == 0:
            return False
        for ta, tb in zip(tokens_a, tokens_b):
            if ta.type in (TokenType.KEYWORD, TokenType.OPERATOR, TokenType.DELIMITER):
                if ta.type != tb.type or ta.value != tb.value:
                    return False
            elif ta.type in (TokenType.IDENTIFIER, TokenType.LITERAL_NUMBER, TokenType.LITERAL_STRING):
                if tb.type not in (TokenType.IDENTIFIER, TokenType.LITERAL_NUMBER, TokenType.LITERAL_STRING):
                    return False
            else:
                if ta.type != tb.type or ta.value != tb.value:
                    return False
        return True

    def _compute_jaccard_similarity(self, tokens_a: List[str], tokens_b: List[str], n_gram: int = 2) -> float:
        if not tokens_a or not tokens_b:
            return 0.0

        def get_ngrams(tokens):
            if len(tokens) < n_gram:
                return set(tokens)
            return set(tuple(tokens[i:i+n_gram]) for i in range(len(tokens) - n_gram + 1))

        set_a = get_ngrams(tokens_a)
        set_b = get_ngrams(tokens_b)

        intersection = len(set_a.intersection(set_b))
        union = len(set_a.union(set_b))
        return intersection / union if union > 0 else 0.0

    def _compute_line_similarity(self, code_a: str, code_b: str) -> float:
        lines_a = [l.strip() for l in code_a.splitlines() if l.strip()]
        lines_b = [l.strip() for l in code_b.splitlines() if l.strip()]
        if not lines_a and not lines_b:
            return 1.0
        matcher = difflib.SequenceMatcher(None, lines_a, lines_b)
        return matcher.ratio()

    def compare_two_snippets(self, code_a: str, code_b: str, language: str = "generic", threshold: Optional[float] = None) -> Dict[str, Any]:
        """
        Direct comparison of two code snippets (for Playground & CLI direct compare).
        """
        start_t = time.perf_counter()
        active_threshold = threshold if threshold is not None else self.similarity_threshold

        tokens_a = Tokenizer.tokenize(code_a, language)
        tokens_b = Tokenizer.tokenize(code_b, language)

        raw_a = [t.value for t in tokens_a]
        raw_b = [t.value for t in tokens_b]

        norm_a, map_a = Normalizer.normalize_type2(tokens_a)
        norm_b, map_b = Normalizer.normalize_type2(tokens_b)

        # 1. Check Type-1 Exact Clone
        is_type1 = (raw_a == raw_b and len(raw_a) > 0)
        # Also check if only the enclosing class/struct name differs (mandatory Java/C++ filename binding)
        if not is_type1 and len(raw_a) == len(raw_b) and len(raw_a) > 5:
            diff_indices = [i for i in range(len(raw_a)) if raw_a[i] != raw_b[i]]
            if len(diff_indices) == 1:
                idx = diff_indices[0]
                if idx > 0 and tokens_a[idx - 1].value in ("class", "struct", "interface"):
                    is_type1 = True

        if is_type1:
            elapsed_ms = round((time.perf_counter() - start_t) * 1000, 2)
            return {
                "clone_type": CloneType.TYPE_1,
                "similarity": 100.0,
                "token_count": len(raw_a),
                "is_clone": True,
                "tokens_a": len(raw_a),
                "tokens_b": len(raw_b),
                "execution_time_ms": elapsed_ms,
                "explanation": "Code fragments have identical token sequences (Type-1 exact logic clone). Differences are only in formatting, indentation, comments, or class name binding.",
                "refactoring_suggestion": "Extract to a single shared function or common utility module to eliminate duplication."
            }

        # 2. Check Type-2 Renamed Clone
        if (norm_a == norm_b and len(norm_a) > 0) or self._is_type2_structural_match(tokens_a, tokens_b):
            elapsed_ms = round((time.perf_counter() - start_t) * 1000, 2)
            return {
                "clone_type": CloneType.TYPE_2,
                "similarity": 100.0,
                "token_count": len(norm_a),
                "is_clone": True,
                "tokens_a": len(raw_a),
                "tokens_b": len(raw_b),
                "execution_time_ms": elapsed_ms,
                "explanation": "Syntactically identical structure with renamed identifiers (variables/functions) or literals.",
                "refactoring_suggestion": "Parameterize method: replace renamed identifiers with arguments or apply generic types."
            }

        # 3. Check Type-3 Near-Miss Clone
        jaccard_sim = self._compute_jaccard_similarity(norm_a, norm_b, n_gram=2)
        line_sim = self._compute_line_similarity(code_a, code_b)
        token_seq_sim = difflib.SequenceMatcher(None, norm_a, norm_b).ratio()

        # Weighted aggregate similarity
        combined_sim = (token_seq_sim * 0.5) + (jaccard_sim * 0.3) + (line_sim * 0.2)
        sim_percentage = round(combined_sim * 100, 2)
        elapsed_ms = round((time.perf_counter() - start_t) * 1000, 2)

        if sim_percentage >= (active_threshold * 100):
            return {
                "clone_type": CloneType.TYPE_3,
                "similarity": sim_percentage,
                "token_count": max(len(norm_a), len(norm_b)),
                "is_clone": True,
                "tokens_a": len(raw_a),
                "tokens_b": len(raw_b),
                "execution_time_ms": elapsed_ms,
                "explanation": f"Near-miss clone with {sim_percentage}% structural similarity. Statements have been added, removed, or modified.",
                "refactoring_suggestion": "Extract Common Superclass / Template Method or use Strategy Pattern to encapsulate variations."
            }

        return {
            "clone_type": CloneType.NON_CLONE,
            "similarity": sim_percentage,
            "token_count": max(len(norm_a), len(norm_b)),
            "is_clone": False,
            "tokens_a": len(raw_a),
            "tokens_b": len(raw_b),
            "execution_time_ms": elapsed_ms,
            "explanation": f"Similarity ({sim_percentage}%) is below the clone detection threshold ({int(active_threshold*100)}%). Fragments represent distinct logic.",
            "refactoring_suggestion": "No refactoring required. Code fragments are sufficiently distinct."
        }

    def scan_files(self, file_contents: Dict[str, str], threshold: Optional[float] = None) -> Dict[str, Any]:
        """
        Batch detection across multiple files using Rabin-Karp indexing and candidate extension.
        file_contents: Dict[file_path, content_str]
        """
        scan_start = time.perf_counter()
        active_threshold = threshold if threshold is not None else self.similarity_threshold

        # 1. Parse and tokenize all files
        parsed_files = {}
        for path, code in file_contents.items():
            lang = Tokenizer.detect_language(path)
            tokens = Tokenizer.tokenize(code, lang)
            raw_tokens = [t.value for t in tokens]
            norm_tokens, _ = Normalizer.normalize_type2(tokens)
            parsed_files[path] = {
                "code": code,
                "tokens": tokens,
                "raw_tokens": raw_tokens,
                "norm_tokens": norm_tokens,
                "lang": lang,
                "line_count": len(code.splitlines())
            }

        # 2. Build Inverted Index on Rolling Hashes (both Raw and Normalized)
        # hash -> list of (path, start_tok, end_tok, is_normalized)
        index = defaultdict(list)

        for path, pdata in parsed_files.items():
            # Raw tokens for Type-1
            raw_hashes = self.hasher.compute_hashes(pdata["raw_tokens"])
            for hval, s_idx, e_idx in raw_hashes:
                index[("raw", hval)].append((path, s_idx, e_idx))

            # Normalized tokens for Type-2
            norm_hashes = self.hasher.compute_hashes(pdata["norm_tokens"])
            for hval, s_idx, e_idx in norm_hashes:
                index[("norm", hval)].append((path, s_idx, e_idx))

        # 3. Match candidate windows and extend maximal clone blocks
        candidate_blocks = []
        covered_ranges = defaultdict(list)

        for (mode, hval), occurrences in index.items():
            if len(occurrences) < 2:
                continue

            for i in range(len(occurrences)):
                for j in range(i + 1, len(occurrences)):
                    path_a, s_a, e_a = occurrences[i]
                    path_b, s_b, e_b = occurrences[j]

                    # If same file and overlapping window, skip self-overlap
                    if path_a == path_b and abs(s_a - s_b) < self.window_size:
                        continue

                    p_first, p_second = (path_a, path_b) if path_a <= path_b else (path_b, path_a)
                    s_first, e_first = (s_a, e_a) if path_a <= path_b else (s_b, e_b)
                    s_second, e_second = (s_b, e_b) if path_a <= path_b else (s_a, e_a)
                    pair_key = (p_first, p_second)

                    # Check if already covered by an existing maximal block
                    already_covered = False
                    for ex_sa, ex_ea, ex_sb, ex_eb, ex_mode in covered_ranges[pair_key]:
                        if ex_mode == mode and ex_sa <= s_first and e_first <= ex_ea and ex_sb <= s_second and e_second <= ex_eb:
                            already_covered = True
                            break
                    if already_covered:
                        continue

                    stream_a = parsed_files[p_first]["raw_tokens"] if mode == "raw" else parsed_files[p_first]["norm_tokens"]
                    stream_b = parsed_files[p_second]["raw_tokens"] if mode == "raw" else parsed_files[p_second]["norm_tokens"]

                    # Expand backward
                    curr_s_a = s_first
                    curr_s_b = s_second
                    while curr_s_a > 0 and curr_s_b > 0 and stream_a[curr_s_a - 1] == stream_b[curr_s_b - 1]:
                        curr_s_a -= 1
                        curr_s_b -= 1

                    # Expand forward
                    curr_e_a = e_first
                    curr_e_b = e_second
                    len_a = len(stream_a)
                    len_b = len(stream_b)
                    while curr_e_a < len_a and curr_e_b < len_b and stream_a[curr_e_a] == stream_b[curr_e_b]:
                        curr_e_a += 1
                        curr_e_b += 1

                    token_span = curr_e_a - curr_s_a
                    if token_span < self.window_size:
                        continue

                    covered_ranges[pair_key].append((curr_s_a, curr_e_a, curr_s_b, curr_e_b, mode))
                    candidate_blocks.append((p_first, p_second, curr_s_a, curr_e_a, curr_s_b, curr_e_b, mode, token_span))

        # Filter out subsumed candidate blocks
        candidate_blocks.sort(key=lambda b: b[7], reverse=True)
        kept_blocks = []
        for block in candidate_blocks:
            pa, pb, sa, ea, sb, eb, mode, span = block
            subsumed = False
            for kpa, kpb, ksa, kea, ksb, keb, kmode, kspan in kept_blocks:
                if pa == kpa and pb == kpb:
                    if ksa <= sa and ea <= kea and ksb <= sb and eb <= keb:
                        subsumed = True
                        break
            if not subsumed:
                kept_blocks.append(block)

        matched_pairs: List[ClonePair] = []
        for pa, pb, sa, ea, sb, eb, mode, span in kept_blocks:
            toks_a_obj = parsed_files[pa]["tokens"]
            toks_b_obj = parsed_files[pb]["tokens"]

            start_line_a = toks_a_obj[sa].line
            end_line_a = toks_a_obj[ea - 1].line
            start_line_b = toks_b_obj[sb].line
            end_line_b = toks_b_obj[eb - 1].line

            snippet_a = self._extract_lines(parsed_files[pa]["code"], start_line_a, end_line_a)
            snippet_b = self._extract_lines(parsed_files[pb]["code"], start_line_b, end_line_b)

            raw_sub_a = parsed_files[pa]["raw_tokens"][sa:ea]
            raw_sub_b = parsed_files[pb]["raw_tokens"][sb:eb]

            if raw_sub_a == raw_sub_b:
                c_type = CloneType.TYPE_1
                sim = 100.0
                refactor = "Extract to common shared function or helper module."
            else:
                c_type = CloneType.TYPE_2
                sim = 100.0 if (ea - sa == len(toks_a_obj) and eb - sb == len(toks_b_obj)) else 95.0
                refactor = "Parameterize variable names and unify into a reusable template or function."

            frag_a = CloneFragment(pa, pa, start_line_a, end_line_a, sa, ea, snippet_a)
            frag_b = CloneFragment(pb, pb, start_line_b, end_line_b, sb, eb, snippet_b)
            matched_pairs.append(ClonePair(frag_a, frag_b, c_type, sim, span, refactor))

        # 4. Pair-wise checks for Type-3 Near-Miss Clones
        file_paths = sorted(list(parsed_files.keys()))
        for i in range(len(file_paths)):
            for j in range(i + 1, len(file_paths)):
                p_a = file_paths[i]
                p_b = file_paths[j]

                len_tok_a = len(parsed_files[p_a]["tokens"])
                len_tok_b = len(parsed_files[p_b]["tokens"])

                # Check if already covered by high-coverage Type-1 or Type-2 match
                covered_tok_a = sum(
                    (p.fragment_a.end_token_idx - p.fragment_a.start_token_idx)
                    for p in matched_pairs
                    if (p.fragment_a.file_path == p_a and p.fragment_b.file_path == p_b) or
                       (p.fragment_a.file_path == p_b and p.fragment_b.file_path == p_a)
                )

                if len_tok_a > 0 and (covered_tok_a / len_tok_a) >= 0.75:
                    continue

                cmp_res = self.compare_two_snippets(
                    parsed_files[p_a]["code"],
                    parsed_files[p_b]["code"],
                    parsed_files[p_a]["lang"],
                    threshold=active_threshold
                )

                if cmp_res["is_clone"] and cmp_res["clone_type"] == CloneType.TYPE_3:
                    # Remove any tiny fragmented sub-window pair between p_a and p_b
                    matched_pairs = [
                        p for p in matched_pairs
                        if not ((p.fragment_a.file_path == p_a and p.fragment_b.file_path == p_b) or
                                (p.fragment_a.file_path == p_b and p.fragment_b.file_path == p_a))
                    ]

                    line_count_a = parsed_files[p_a]["line_count"]
                    line_count_b = parsed_files[p_b]["line_count"]
                    frag_a = CloneFragment(p_a, p_a, 1, line_count_a, 0, len_tok_a, parsed_files[p_a]["code"])
                    frag_b = CloneFragment(p_b, p_b, 1, line_count_b, 0, len_tok_b, parsed_files[p_b]["code"])
                    matched_pairs.append(ClonePair(
                        frag_a, frag_b, cmp_res["clone_type"], cmp_res["similarity"],
                        cmp_res["token_count"], cmp_res["refactoring_suggestion"]
                    ))

        # Sort clone pairs by similarity descending
        matched_pairs.sort(key=lambda p: (p.similarity, p.token_count), reverse=True)

        # 5. Calculate Metrics
        total_files = len(file_contents)
        total_lines = sum(p["line_count"] for p in parsed_files.values())
        cloned_files = set()
        cloned_lines_count = 0

        for pair in matched_pairs:
            cloned_files.add(pair.fragment_a.file_path)
            cloned_files.add(pair.fragment_b.file_path)
            cloned_lines_count += (pair.fragment_a.end_line - pair.fragment_a.start_line + 1)
            cloned_lines_count += (pair.fragment_b.end_line - pair.fragment_b.start_line + 1)

        # Avoid double-counting if cloned lines exceed total
        cloned_lines_count = min(cloned_lines_count, total_lines)
        duplication_percentage = round((cloned_lines_count / total_lines * 100), 1) if total_lines > 0 else 0.0

        type1_count = sum(1 for p in matched_pairs if p.clone_type == CloneType.TYPE_1)
        type2_count = sum(1 for p in matched_pairs if p.clone_type == CloneType.TYPE_2)
        type3_count = sum(1 for p in matched_pairs if p.clone_type == CloneType.TYPE_3)

        elapsed_ms = round((time.perf_counter() - scan_start) * 1000, 2)

        return {
            "total_files": total_files,
            "total_lines": total_lines,
            "cloned_files_count": len(cloned_files),
            "cloned_lines_count": cloned_lines_count,
            "duplication_percentage": duplication_percentage,
            "clone_pairs_count": len(matched_pairs),
            "execution_time_ms": elapsed_ms,
            "clone_breakdown": {
                "Type-1": type1_count,
                "Type-2": type2_count,
                "Type-3": type3_count
            },
            "clone_pairs": [p.to_dict() for p in matched_pairs]
        }
