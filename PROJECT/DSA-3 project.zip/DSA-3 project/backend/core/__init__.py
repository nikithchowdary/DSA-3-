"""
Core clone detection package.
"""
from .tokenizer import Tokenizer, Token, TokenType
from .normalizer import Normalizer
from .rabin_karp import RabinKarpHasher
from .detector import CloneDetector, CloneType, ClonePair, CloneFragment
from .cluster import CloneClusterer
from .refactoring import RefactoringEngine
from .visual_report import generate_html_visual_report
