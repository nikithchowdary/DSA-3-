"""
Standalone Visual Report Generator for Source Code Clone Detector.
Generates self-contained, interactive HTML reports highlighting clone pairs,
similarity percentage, code locations, and automated refactorings.
"""

import html
import json
from datetime import datetime
from typing import Dict, Any, List

def generate_html_visual_report(scan_data: Dict[str, Any], title: str = "Source Code Clone Detection Report") -> str:
    """
    Renders a comprehensive, self-contained visual HTML report.
    scan_data should contain:
      - scan_name, scan_type, language, total_files, total_lines
      - cloned_files_count, cloned_lines_count, duplication_percentage
      - execution_time_ms, clone_breakdown, clone_pairs, clusters
    """
    scan_name = scan_data.get("scan_name", "Codebase Scan")
    scan_type = scan_data.get("scan_type", "multi-file")
    language = scan_data.get("language", "multi")
    total_files = scan_data.get("total_files", 0)
    total_lines = scan_data.get("total_lines", 0)
    cloned_lines = scan_data.get("cloned_lines_count", 0)
    duplication_pct = scan_data.get("duplication_percentage", 0.0)
    runtime_ms = scan_data.get("execution_time_ms", 0.0)
    clone_pairs = scan_data.get("clone_pairs", [])
    clusters = scan_data.get("clusters", [])
    breakdown = scan_data.get("clone_breakdown", {})
    t1_count = breakdown.get("Type-1", 0) or breakdown.get("Type-1 (Exact)", 0)
    t2_count = breakdown.get("Type-2", 0) or breakdown.get("Type-2 (Renamed)", 0)
    t3_count = breakdown.get("Type-3", 0) or breakdown.get("Type-3 (Near-Miss)", 0)
    total_pairs = len(clone_pairs)
    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # JSON payload for client-side search & filtering
    json_pairs_str = json.dumps(clone_pairs).replace("</script>", "<\\/script>")

    report_html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{html.escape(title)} - {html.escape(scan_name)}</title>
  <style>
    :root {{
      --bg: #0b0f19;
      --card-bg: rgba(18, 24, 38, 0.85);
      --card-border: rgba(255, 255, 255, 0.08);
      --text: #f1f5f9;
      --text-muted: #94a3b8;
      --primary: #38bdf8;
      --primary-glow: rgba(56, 189, 248, 0.2);
      --type1: #10b981;
      --type1-bg: rgba(16, 185, 129, 0.12);
      --type2: #0284c7;
      --type2-bg: rgba(2, 132, 199, 0.15);
      --type3: #f59e0b;
      --type3-bg: rgba(245, 158, 11, 0.15);
      --font-code: 'Fira Code', Menlo, Monaco, Consolas, 'Courier New', monospace;
    }}
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{
      background: var(--bg);
      color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      line-height: 1.5;
      padding: 30px 20px;
      -webkit-font-smoothing: antialiased;
    }}
    .container {{
      max-width: 1200px;
      margin: 0 auto;
    }}
    /* Header */
    .report-header {{
      background: linear-gradient(135deg, rgba(30, 41, 59, 0.9) 0%, rgba(15, 23, 42, 0.95) 100%);
      border: 1px solid var(--card-border);
      border-radius: 16px;
      padding: 28px;
      margin-bottom: 24px;
      backdrop-filter: blur(12px);
      box-shadow: 0 10px 30px rgba(0,0,0,0.3);
      position: relative;
    }}
    .header-top {{
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      flex-wrap: wrap;
      gap: 16px;
      margin-bottom: 16px;
    }}
    .title-group h1 {{
      font-size: 1.85rem;
      font-weight: 700;
      color: #fff;
      display: flex;
      align-items: center;
      gap: 12px;
    }}
    .title-group h1 span {{
      color: var(--primary);
    }}
    .badge {{
      display: inline-block;
      padding: 4px 10px;
      font-size: 0.75rem;
      font-weight: 600;
      border-radius: 6px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }}
    .course-badge {{
      background: rgba(56, 189, 248, 0.15);
      color: #38bdf8;
      border: 1px solid rgba(56, 189, 248, 0.3);
    }}
    .header-meta {{
      font-size: 0.88rem;
      color: var(--text-muted);
      display: flex;
      flex-wrap: wrap;
      gap: 18px;
      margin-top: 10px;
    }}
    .header-meta strong {{
      color: #e2e8f0;
    }}
    .header-actions {{
      display: flex;
      gap: 10px;
    }}
    .btn {{
      padding: 8px 16px;
      border-radius: 8px;
      font-weight: 600;
      font-size: 0.85rem;
      cursor: pointer;
      border: none;
      transition: all 0.2s;
    }}
    .btn-primary {{
      background: #0284c7;
      color: #fff;
    }}
    .btn-primary:hover {{
      background: #0369a1;
    }}
    /* Metrics Grid */
    .kpi-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
      gap: 16px;
      margin-bottom: 24px;
    }}
    .kpi-card {{
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 12px;
      padding: 20px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }}
    .kpi-label {{
      font-size: 0.8rem;
      color: var(--text-muted);
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 6px;
    }}
    .kpi-val {{
      font-size: 2rem;
      font-weight: 700;
      color: #fff;
    }}
    .kpi-val.highlight-green {{ color: #10b981; }}
    .kpi-val.highlight-blue {{ color: #38bdf8; }}
    .kpi-val.highlight-amber {{ color: #f59e0b; }}
    .kpi-sub {{
      font-size: 0.8rem;
      color: var(--text-muted);
      margin-top: 4px;
    }}
    /* Breakdown Bar */
    .breakdown-card {{
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 12px;
      padding: 18px 22px;
      margin-bottom: 24px;
    }}
    .breakdown-header {{
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 12px;
      margin-bottom: 12px;
    }}
    .breakdown-title {{
      font-size: 1rem;
      font-weight: 600;
    }}
    .breakdown-tags {{
      display: flex;
      gap: 16px;
      font-size: 0.85rem;
    }}
    .legend-item {{
      display: flex;
      align-items: center;
      gap: 6px;
    }}
    .dot {{
      width: 10px;
      height: 10px;
      border-radius: 50%;
    }}
    .dot-t1 {{ background: var(--type1); }}
    .dot-t2 {{ background: var(--type2); }}
    .dot-t3 {{ background: var(--type3); }}
    .progress-bar {{
      height: 10px;
      background: rgba(255, 255, 255, 0.05);
      border-radius: 5px;
      display: flex;
      overflow: hidden;
    }}
    .progress-seg {{
      height: 100%;
      transition: width 0.3s;
    }}
    .seg-t1 {{ background: var(--type1); }}
    .seg-t2 {{ background: var(--type2); }}
    .seg-t3 {{ background: var(--type3); }}
    /* Filter Toolbar */
    .filter-bar {{
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 12px;
      padding: 14px 20px;
      margin-bottom: 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 12px;
    }}
    .filter-pills {{
      display: flex;
      gap: 8px;
    }}
    .filter-btn {{
      padding: 6px 14px;
      border-radius: 6px;
      font-size: 0.85rem;
      cursor: pointer;
      border: 1px solid var(--card-border);
      background: rgba(255, 255, 255, 0.03);
      color: var(--text-muted);
      transition: all 0.2s;
    }}
    .filter-btn.active {{
      background: rgba(56, 189, 248, 0.15);
      color: #38bdf8;
      border-color: rgba(56, 189, 248, 0.4);
    }}
    .search-box {{
      padding: 8px 14px;
      border-radius: 6px;
      border: 1px solid var(--card-border);
      background: rgba(15, 23, 42, 0.6);
      color: #fff;
      font-size: 0.85rem;
      width: 260px;
      outline: none;
    }}
    /* Clone Pair Cards */
    .pairs-container {{
      display: flex;
      flex-direction: column;
      gap: 18px;
    }}
    .pair-card {{
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 14px;
      padding: 22px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.2);
      transition: border-color 0.2s;
    }}
    .pair-card:hover {{
      border-color: rgba(56, 189, 248, 0.35);
    }}
    .pair-top {{
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      flex-wrap: wrap;
      gap: 14px;
      margin-bottom: 16px;
    }}
    .pair-info {{
      display: flex;
      align-items: center;
      gap: 10px;
      flex-wrap: wrap;
    }}
    .pair-idx {{
      font-size: 0.9rem;
      font-weight: 700;
      color: var(--primary);
    }}
    .type-badge {{
      padding: 4px 10px;
      border-radius: 6px;
      font-size: 0.8rem;
      font-weight: 600;
    }}
    .badge-t1 {{ background: var(--type1-bg); color: var(--type1); border: 1px solid rgba(16, 185, 129, 0.3); }}
    .badge-t2 {{ background: var(--type2-bg); color: var(--type2); border: 1px solid rgba(2, 132, 199, 0.3); }}
    .badge-t3 {{ background: var(--type3-bg); color: var(--type3); border: 1px solid rgba(245, 158, 11, 0.3); }}
    .sim-pill {{
      font-size: 0.95rem;
      font-weight: 700;
      color: #38bdf8;
      background: rgba(56, 189, 248, 0.1);
      padding: 3px 10px;
      border-radius: 6px;
      border: 1px solid rgba(56, 189, 248, 0.25);
    }}
    .locations-bar {{
      background: rgba(15, 23, 42, 0.7);
      border: 1px solid var(--card-border);
      border-radius: 8px;
      padding: 10px 14px;
      margin-bottom: 16px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 12px;
      font-size: 0.88rem;
    }}
    .loc-tag {{
      display: flex;
      align-items: center;
      gap: 6px;
      font-family: var(--font-code);
      color: #e2e8f0;
    }}
    .loc-pill {{
      background: rgba(255, 255, 255, 0.08);
      padding: 2px 8px;
      border-radius: 4px;
      font-size: 0.8rem;
    }}
    .loc-sep {{
      color: var(--primary);
      font-weight: bold;
    }}
    /* Side by side code view */
    .diff-view {{
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
      background: #070b13;
      border: 1px solid rgba(255, 255, 255, 0.06);
      border-radius: 8px;
      overflow: hidden;
      margin-bottom: 14px;
    }}
    @media (max-width: 768px) {{
      .diff-view {{ grid-template-columns: 1fr; }}
    }}
    .code-col {{
      padding: 12px;
      overflow-x: auto;
      font-family: var(--font-code);
      font-size: 0.82rem;
      line-height: 1.5;
      color: #cbd5e1;
      max-height: 320px;
      overflow-y: auto;
    }}
    .code-col:first-child {{
      border-right: 1px solid rgba(255, 255, 255, 0.06);
    }}
    .col-header {{
      font-size: 0.75rem;
      font-weight: 600;
      color: var(--text-muted);
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 8px;
      padding-bottom: 4px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    }}
    .code-line {{
      white-space: pre;
    }}
    /* Refactoring Advice */
    .refactor-box {{
      background: rgba(16, 185, 129, 0.08);
      border: 1px solid rgba(16, 185, 129, 0.2);
      border-radius: 8px;
      padding: 10px 14px;
      font-size: 0.85rem;
      color: #a7f3d0;
      display: flex;
      align-items: center;
      gap: 10px;
    }}
    /* DSU Clusters */
    .clusters-card {{
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 12px;
      padding: 22px;
      margin-top: 24px;
    }}
    .clusters-title {{
      font-size: 1.1rem;
      font-weight: 600;
      margin-bottom: 14px;
      display: flex;
      align-items: center;
      gap: 8px;
    }}
    .clusters-list {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 14px;
    }}
    .cluster-item {{
      background: rgba(15, 23, 42, 0.6);
      border: 1px solid var(--card-border);
      border-radius: 8px;
      padding: 14px;
    }}
    .cluster-head {{
      font-weight: 700;
      color: var(--primary);
      margin-bottom: 6px;
      font-size: 0.9rem;
    }}
    .cluster-loc {{
      font-size: 0.8rem;
      color: var(--text-muted);
      font-family: var(--font-code);
      margin-top: 3px;
    }}
    /* Footer */
    .report-footer {{
      margin-top: 40px;
      text-align: center;
      font-size: 0.82rem;
      color: var(--text-muted);
      border-top: 1px solid var(--card-border);
      padding-top: 20px;
    }}
    @media print {{
      body {{ background: #fff; color: #000; padding: 0; }}
      .header-actions, .filter-bar {{ display: none; }}
      .report-header, .kpi-card, .pair-card {{ border: 1px solid #ccc; background: #fff; box-shadow: none; color: #000; }}
      .kpi-val, .title-group h1 {{ color: #000; }}
      .diff-view {{ background: #f8fafc; border: 1px solid #ccc; }}
      .code-col {{ color: #000; }}
    }}
  </style>
</head>
<body>
  <div class="container">
    <!-- Header -->
    <header class="report-header">
      <div class="header-top">
        <div class="title-group">
          <h1>Source <span>Clone Detector</span> <span class="badge course-badge">DSA-3 • 25CS1302E</span></h1>
          <div class="header-meta">
            <span><strong>Scan:</strong> {html.escape(scan_name)}</span>
            <span><strong>Type:</strong> {html.escape(scan_type)}</span>
            <span><strong>Language:</strong> {html.escape(language)}</span>
            <span><strong>Generated:</strong> {generated_at}</span>
            <span><strong>Runtime:</strong> {runtime_ms} ms</span>
          </div>
        </div>
        <div class="header-actions">
          <button class="btn btn-primary" onclick="window.print()">🖨️ Print / Save PDF</button>
        </div>
      </div>
      <div class="header-meta" style="margin-top: 8px; border-top: 1px solid rgba(255,255,255,0.06); padding-top: 10px;">
        <span><strong>Course:</strong> Database Systems Engg & Distributed Backend</span>
        <span><strong>Guide:</strong> Dr. Dyuti Banerjee</span>
        <span><strong>Team 02:</strong> V. Nikith (2520090219), T. Harsha Vardhan (2520080047), D. Satvarsh (2520090080)</span>
      </div>
    </header>

    <!-- KPI Grid -->
    <div class="kpi-grid">
      <div class="kpi-card">
        <div class="kpi-label">Code Duplication</div>
        <div class="kpi-val {'highlight-green' if duplication_pct < 20 else 'highlight-amber'}">{duplication_pct}%</div>
        <div class="kpi-sub">{cloned_lines} of {total_lines} total lines duplicated</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Clone Pairs Found</div>
        <div class="kpi-val highlight-blue">{total_pairs}</div>
        <div class="kpi-sub">Across {total_files} analyzed files</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">DSU Clone Classes</div>
        <div class="kpi-val highlight-green">{len(clusters)}</div>
        <div class="kpi-sub">Equivalence components via DSU</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Execution Speed</div>
        <div class="kpi-val">{runtime_ms} <span style="font-size:1rem; font-weight:normal; color:#94a3b8;">ms</span></div>
        <div class="kpi-sub">Rabin-Karp rolling polynomial hashing</div>
      </div>
    </div>

    <!-- Breakdown Progress Bar -->
    <div class="breakdown-card">
      <div class="breakdown-header">
        <span class="breakdown-title">Clone Taxonomy Distribution</span>
        <div class="breakdown-tags">
          <div class="legend-item"><span class="dot dot-t1"></span> Type-1 (Exact): <strong>{t1_count}</strong></div>
          <div class="legend-item"><span class="dot dot-t2"></span> Type-2 (Renamed): <strong>{t2_count}</strong></div>
          <div class="legend-item"><span class="dot dot-t3"></span> Type-3 (Near-Miss): <strong>{t3_count}</strong></div>
        </div>
      </div>
      <div class="progress-bar">
        <div class="progress-seg seg-t1" style="width: {(t1_count/max(1, total_pairs))*100}%" title="Type-1 Exact"></div>
        <div class="progress-seg seg-t2" style="width: {(t2_count/max(1, total_pairs))*100}%" title="Type-2 Renamed"></div>
        <div class="progress-seg seg-t3" style="width: {(t3_count/max(1, total_pairs))*100}%" title="Type-3 Near-Miss"></div>
      </div>
    </div>

    <!-- Filter & Search Toolbar -->
    <div class="filter-bar">
      <div class="filter-pills">
        <button class="filter-btn active" onclick="filterPairs('all', this)">All Pairs ({total_pairs})</button>
        <button class="filter-btn" onclick="filterPairs('Type-1', this)">Type-1 Exact ({t1_count})</button>
        <button class="filter-btn" onclick="filterPairs('Type-2', this)">Type-2 Renamed ({t2_count})</button>
        <button class="filter-btn" onclick="filterPairs('Type-3', this)">Type-3 Near-Miss ({t3_count})</button>
      </div>
      <input type="text" id="searchInput" class="search-box" placeholder="Filter by file or line..." onkeyup="searchPairs(this.value)">
    </div>

    <!-- Clone Pairs Section -->
    <div class="pairs-container" id="pairsContainer">
"""

    if not clone_pairs:
        report_html += """
      <div class="pair-card" style="text-align:center; padding: 40px; color: #94a3b8;">
        <h3>No Code Clones Detected</h3>
        <p>Codebase logic is clean and distinct below the configured similarity threshold.</p>
      </div>
"""
    else:
        for idx, p in enumerate(clone_pairs, start=1):
            ctype = p.get("clone_type", "")
            sim = p.get("similarity", 0.0)
            fa = p.get("fragment_a", {})
            fb = p.get("fragment_b", {})
            code_a = fa.get("code_snippet", "")
            code_b = fb.get("code_snippet", "")
            refactor = p.get("refactoring_suggestion", "")

            badge_class = "badge-t1"
            if "Type-2" in ctype: badge_class = "badge-t2"
            elif "Type-3" in ctype: badge_class = "badge-t3"

            path_a = fa.get("file_path", "Fragment A")
            path_b = fb.get("file_path", "Fragment B")
            lines_a = f"Lines {fa.get('start_line', 1)}-{fa.get('end_line', 1)}"
            lines_b = f"Lines {fb.get('start_line', 1)}-{fb.get('end_line', 1)}"

            report_html += f"""
      <div class="pair-card" data-type="{html.escape(ctype)}" data-search="{html.escape(path_a.lower())} {html.escape(path_b.lower())} {fa.get('start_line', 1)} {fb.get('start_line', 1)}">
        <div class="pair-top">
          <div class="pair-info">
            <span class="pair-idx">Pair #{idx:02d}</span>
            <span class="type-badge {badge_class}">{html.escape(ctype)}</span>
            <span class="sim-pill">{sim}% Match</span>
            <span style="font-size:0.8rem; color:var(--text-muted);">{p.get('token_count', 0)} Tokens</span>
          </div>
        </div>

        <div class="locations-bar">
          <div class="loc-tag">
            <span>📄</span>
            <strong>{html.escape(path_a)}</strong>
            <span class="loc-pill">{lines_a}</span>
          </div>
          <span class="loc-sep">⇄</span>
          <div class="loc-tag">
            <span>📄</span>
            <strong>{html.escape(path_b)}</strong>
            <span class="loc-pill">{lines_b}</span>
          </div>
        </div>

        <div class="diff-view">
          <div class="code-col">
            <div class="col-header">Fragment A: {html.escape(path_a)} ({lines_a})</div>
            <pre><code>{html.escape(code_a)}</code></pre>
          </div>
          <div class="code-col">
            <div class="col-header">Fragment B: {html.escape(path_b)} ({lines_b})</div>
            <pre><code>{html.escape(code_b)}</code></pre>
          </div>
        </div>

        <div class="refactor-box">
          <span>💡</span>
          <div><strong>Refactoring Advice:</strong> {html.escape(refactor if refactor else "Extract to common shared function or parameterize variables.")}</div>
        </div>
      </div>
"""

    # DSU Clusters Section
    if clusters:
        report_html += """
    <div class="clusters-card">
      <div class="clusters-title">
        <span>🔗</span>
        <span>DSU Clone Classes (Equivalence Groups)</span>
      </div>
      <div class="clusters-list">
"""
        for c in clusters:
            cid = c.get("cluster_id", "Cluster")
            mcount = c.get("member_count", 0)
            alines = c.get("average_lines", 0)
            report_html += f"""
        <div class="cluster-item">
          <div class="cluster-head">{html.escape(cid)} ({mcount} locations, avg {alines} lines)</div>
"""
            for frag in c.get("fragments", []):
                report_html += f"""
          <div class="cluster-loc">• {html.escape(frag.get('file_path', ''))} (L{frag.get('start_line', 1)}-L{frag.get('end_line', 1)})</div>
"""
            report_html += """
        </div>
"""
        report_html += """
      </div>
    </div>
"""

    report_html += f"""
    <!-- Footer -->
    <footer class="report-footer">
      <p>Source Code Clone Detector • Course: 25CS1302E • Team 02</p>
      <p>Faculty Guide: Dr. Dyuti Banerjee • Generated {generated_at}</p>
    </footer>
  </div>

  <script>
    let activeType = 'all';
    let searchQuery = '';

    function filterPairs(type, btn) {{
      activeType = type;
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      if (btn) btn.classList.add('active');
      applyFilters();
    }}

    function searchPairs(query) {{
      searchQuery = (query || '').toLowerCase().trim();
      applyFilters();
    }}

    function applyFilters() {{
      const cards = document.querySelectorAll('.pair-card');
      cards.forEach(card => {{
        const cardType = card.getAttribute('data-type') || '';
        const cardSearch = card.getAttribute('data-search') || '';

        const typeMatch = (activeType === 'all') || cardType.includes(activeType);
        const searchMatch = !searchQuery || cardSearch.includes(searchQuery);

        if (typeMatch && searchMatch) {{
          card.style.display = 'block';
        }} else {{
          card.style.display = 'none';
        }}
      }});
    }}
  </script>
</body>
</html>
"""
    return report_html
