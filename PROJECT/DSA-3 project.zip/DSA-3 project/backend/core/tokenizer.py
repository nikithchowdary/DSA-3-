"""
Multi-Language Tokenizer for Source Clone Detection.
Supports Python, Java, C/C++, and JavaScript.
"""

import re
from typing import List, Optional

class TokenType:
    KEYWORD = "KEYWORD"
    IDENTIFIER = "IDENTIFIER"
    LITERAL_NUMBER = "LITERAL_NUMBER"
    LITERAL_STRING = "LITERAL_STRING"
    OPERATOR = "OPERATOR"
    DELIMITER = "DELIMITER"
    COMMENT = "COMMENT"
    WHITESPACE = "WHITESPACE"
    UNKNOWN = "UNKNOWN"

class Token:
    def __init__(self, type_: str, value: str, line: int, col: int, original_value: Optional[str] = None):
        self.type = type_
        self.value = value
        self.line = line
        self.col = col
        self.original_value = original_value if original_value is not None else value

    def __repr__(self):
        return f"Token({self.type}, {self.value!r}, L{self.line}:C{self.col})"

    def to_dict(self):
        return {
            "type": self.type,
            "value": self.value,
            "line": self.line,
            "col": self.col
        }

COMMON_KEYWORDS = {
    "python": {
        "and", "as", "assert", "async", "await", "break", "class", "continue",
        "def", "del", "elif", "else", "except", "finally", "for", "from",
        "global", "if", "import", "in", "is", "lambda", "nonlocal", "not",
        "or", "pass", "raise", "return", "try", "while", "with", "yield",
        "True", "False", "None"
    },
    "java": {
        "abstract", "assert", "boolean", "break", "byte", "case", "catch",
        "char", "class", "const", "continue", "default", "do", "double",
        "else", "enum", "extends", "final", "finally", "float", "for",
        "goto", "if", "implements", "import", "instanceof", "int", "interface",
        "long", "native", "new", "package", "private", "protected", "public",
        "return", "short", "static", "strictfp", "super", "switch", "synchronized",
        "this", "throw", "throws", "transient", "try", "void", "volatile",
        "while", "true", "false", "null"
    },
    "cpp": {
        "auto", "bool", "break", "case", "catch", "char", "class", "const",
        "continue", "default", "delete", "do", "double", "else", "enum",
        "explicit", "export", "extern", "false", "float", "for", "friend",
        "goto", "if", "inline", "int", "long", "mutable", "namespace",
        "new", "operator", "private", "protected", "public", "register",
        "return", "short", "signed", "sizeof", "static", "struct", "switch",
        "template", "this", "throw", "true", "try", "typedef", "typename",
        "union", "unsigned", "using", "virtual", "void", "volatile", "while"
    },
    "javascript": {
        "break", "case", "catch", "class", "const", "continue", "debugger",
        "default", "delete", "do", "else", "export", "extends", "finally",
        "for", "function", "if", "import", "in", "instanceof", "new",
        "return", "super", "switch", "this", "throw", "try", "typeof",
        "var", "void", "while", "with", "yield", "let", "static", "await",
        "async", "true", "false", "null", "undefined"
    }
}

class Tokenizer:
    @staticmethod
    def detect_language(filename: str) -> str:
        lower = filename.lower()
        if lower.endswith(".py"):
            return "python"
        elif lower.endswith(".java"):
            return "java"
        elif lower.endswith((".cpp", ".cxx", ".cc", ".c", ".h", ".hpp")):
            return "cpp"
        elif lower.endswith((".js", ".jsx", ".ts", ".tsx")):
            return "javascript"
        return "generic"

    @classmethod
    def tokenize(cls, source_code: str, language: str = "generic") -> List[Token]:
        lang_key = language.lower()
        if lang_key not in COMMON_KEYWORDS:
            # Fallback to combined keywords
            keywords = set.union(*COMMON_KEYWORDS.values())
        else:
            keywords = COMMON_KEYWORDS[lang_key]

        # Multi-language master regex patterns
        token_specification = [
            ("COMMENT_MULTI", r"/\*[\s\S]*?\*/|(\"\"\"[\s\S]*?\"\"\")|(\'\'\'[\s\S]*?\'\'\')"),
            ("COMMENT_SINGLE", r"//[^\n]*|#[^\n]*"),
            ("LITERAL_STRING", r'`(?:\\.|[^`\\])*`|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\''),
            ("LITERAL_NUMBER", r"\b\d+(?:\.\d+)?(?:[eE][+-]?\d+)?\b|0x[0-9a-fA-F]+"),
            ("IDENTIFIER",     r"[a-zA-Z_][a-zA-Z0-9_]*"),
            ("OPERATOR",       r"==|!=|<=|>=|&&|\|\||\+\+|--|\+=|-=|\*=|/=|%=|->|::|<<|>>|[+\-*/%=<>!&|^~]"),
            ("DELIMITER",      r"[{}()\[\];,.:]"),
            ("NEWLINE",        r"\n"),
            ("WHITESPACE",     r"[ \t\r]+"),
            ("MISC",           r"."),
        ]

        tok_regex = "|".join(f"(?P<{pair[0]}>{pair[1]})" for pair in token_specification)
        tokens: List[Token] = []

        line_num = 1
        line_start = 0

        for mo in re.finditer(tok_regex, source_code):
            kind = mo.lastgroup
            val = mo.group()
            col_num = mo.start() - line_start + 1

            if kind == "NEWLINE":
                line_start = mo.end()
                line_num += 1
                continue
            elif kind in ("WHITESPACE", "COMMENT_SINGLE"):
                continue
            elif kind == "COMMENT_MULTI":
                # Account for newlines inside block comment
                line_num += val.count("\n")
                continue
            elif kind == "IDENTIFIER":
                if val in keywords:
                    tokens.append(Token(TokenType.KEYWORD, val, line_num, col_num))
                else:
                    tokens.append(Token(TokenType.IDENTIFIER, val, line_num, col_num))
            elif kind == "LITERAL_STRING":
                # Check for newlines inside multiline strings
                tokens.append(Token(TokenType.LITERAL_STRING, val, line_num, col_num))
                line_num += val.count("\n")
            elif kind == "LITERAL_NUMBER":
                tokens.append(Token(TokenType.LITERAL_NUMBER, val, line_num, col_num))
            elif kind == "OPERATOR":
                tokens.append(Token(TokenType.OPERATOR, val, line_num, col_num))
            elif kind == "DELIMITER":
                tokens.append(Token(TokenType.DELIMITER, val, line_num, col_num))

        return tokens
