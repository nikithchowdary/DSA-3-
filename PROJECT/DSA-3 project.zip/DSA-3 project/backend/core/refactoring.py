"""
Automated Refactoring Suggestions Engine.
Analyzes clone characteristics and generates clean refactored code templates.
"""

from typing import Dict, Any

class RefactoringEngine:
    @staticmethod
    def generate_refactoring(clone_pair: Dict[str, Any]) -> Dict[str, Any]:
        clone_type = clone_pair.get("clone_type", "")
        frag_a = clone_pair.get("fragment_a", {})
        frag_b = clone_pair.get("fragment_b", {})
        code_a = frag_a.get("code_snippet", "")
        code_b = frag_b.get("code_snippet", "")

        if "Type-1" in clone_type:
            title = "Extract Method / Shared Utility Function"
            strategy = (
                "Both code fragments have identical token logic. Extract the common snippet into a "
                "standalone helper function in a shared utility module (e.g. `utils.py` or `CommonHelper.java`). "
                "Replace both call sites with invocations of the single centralized function."
            )
            code_preview = (
                "# === Suggested Refactored Shared Implementation ===\n"
                "# In shared_utils.py:\n"
                f"{code_a.strip()}\n\n"
                "# === Call Sites in Both Files ===\n"
                "# from shared_utils import ...\n"
                "# call extracted function directly!"
            )
            effort = "Low (Safe Automated Extract)"

        elif "Type-2" in clone_type:
            title = "Parameterize Function & Unify Identifiers"
            strategy = (
                "The code fragments share identical syntactic structure with renamed identifiers or literals. "
                "Generalize the function by introducing parameters for the diverging variable names or values. "
                "This collapses multiple duplicate routines into one clean parameterized function."
            )
            code_preview = (
                "# === Suggested Parameterized Implementation ===\n"
                "# Define a single parameterized function:\n"
                f"{code_a.strip()}\n\n"
                "# Pass parameters dynamically from callers instead of copying the block."
            )
            effort = "Low - Medium (Parameterization)"

        else:
            title = "Template Method / Strategy Pattern Refactoring"
            strategy = (
                "The fragments represent near-miss clones with custom edge checks or diverging branches. "
                "Apply the Template Method pattern: extract invariant core logic into a base template, "
                "and delegate the variable validation or steps to a hook or strategy lambda."
            )
            code_preview = (
                "# === Suggested Template Method Architecture ===\n"
                "# Abstract common skeleton:\n"
                "def execute_template(data, custom_hook=None):\n"
                "    if custom_hook:\n"
                "        custom_hook(data)\n"
                "    # ... Common Core Algorithm ...\n"
            )
            effort = "Medium (Pattern Refactoring)"

        return {
            "title": title,
            "clone_type": clone_type,
            "strategy": strategy,
            "effort": effort,
            "code_preview": code_preview,
            "location_a": f"{frag_a.get('file_path')}:{frag_a.get('start_line')}-{frag_a.get('end_line')}",
            "location_b": f"{frag_b.get('file_path')}:{frag_b.get('start_line')}-{frag_b.get('end_line')}"
        }
