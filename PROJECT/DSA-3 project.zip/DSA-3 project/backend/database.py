"""
Database Persistence Layer for Source Code Clone Detector.
Implements SQLite storage for scans, clone pairs, clusters, and historical metrics.
Fulfills the Database Systems Engineering course requirements.
"""

import sqlite3
import json
import os
from datetime import datetime
from typing import List, Dict, Any, Optional

DB_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_DB_PATH = os.path.join(DB_DIR, "clones.db")

def get_connection(db_path: Optional[str] = None) -> sqlite3.Connection:
    path = db_path or DEFAULT_DB_PATH
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    return conn

def init_db(db_path: Optional[str] = None):
    """Initializes SQLite schema if tables do not exist."""
    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        
        # Scans table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_name TEXT NOT NULL,
                scan_type TEXT NOT NULL, -- 'snippet' or 'multi-file'
                language TEXT DEFAULT 'generic',
                total_files INTEGER DEFAULT 0,
                total_lines INTEGER DEFAULT 0,
                cloned_files_count INTEGER DEFAULT 0,
                cloned_lines_count INTEGER DEFAULT 0,
                duplication_percentage REAL DEFAULT 0.0,
                clone_pairs_count INTEGER DEFAULT 0,
                type1_count INTEGER DEFAULT 0,
                type2_count INTEGER DEFAULT 0,
                type3_count INTEGER DEFAULT 0,
                execution_time_ms REAL DEFAULT 0.0,
                created_at TEXT NOT NULL
            );
        """)

        # Clone pairs table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS clone_pairs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER NOT NULL,
                clone_type TEXT NOT NULL,
                similarity REAL NOT NULL,
                token_count INTEGER DEFAULT 0,
                file_a TEXT,
                start_line_a INTEGER DEFAULT 1,
                end_line_a INTEGER DEFAULT 1,
                code_snippet_a TEXT,
                file_b TEXT,
                start_line_b INTEGER DEFAULT 1,
                end_line_b INTEGER DEFAULT 1,
                code_snippet_b TEXT,
                refactoring_suggestion TEXT,
                FOREIGN KEY (scan_id) REFERENCES scans (id) ON DELETE CASCADE
            );
        """)

        # Clusters table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS clusters (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER NOT NULL,
                cluster_id TEXT NOT NULL,
                member_count INTEGER DEFAULT 0,
                average_lines REAL DEFAULT 0.0,
                summary TEXT,
                fragments_json TEXT,
                FOREIGN KEY (scan_id) REFERENCES scans (id) ON DELETE CASCADE
            );
        """)

        conn.commit()

def save_scan(scan_info: Dict[str, Any], pairs: List[Dict[str, Any]], 
              clusters: Optional[List[Dict[str, Any]]] = None, db_path: Optional[str] = None) -> int:
    """Saves a complete clone detection scan report."""
    init_db(db_path)
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with get_connection(db_path) as conn:
        cursor = conn.cursor()

        breakdown = scan_info.get("clone_breakdown", {})
        cursor.execute("""
            INSERT INTO scans (
                scan_name, scan_type, language, total_files, total_lines,
                cloned_files_count, cloned_lines_count, duplication_percentage,
                clone_pairs_count, type1_count, type2_count, type3_count,
                execution_time_ms, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            scan_info.get("scan_name", "Clone Detection Run"),
            scan_info.get("scan_type", "snippet"),
            scan_info.get("language", "generic"),
            scan_info.get("total_files", 0),
            scan_info.get("total_lines", 0),
            scan_info.get("cloned_files_count", 0),
            scan_info.get("cloned_lines_count", 0),
            scan_info.get("duplication_percentage", 0.0),
            scan_info.get("clone_pairs_count", len(pairs)),
            breakdown.get("Type-1", 0),
            breakdown.get("Type-2", 0),
            breakdown.get("Type-3", 0),
            scan_info.get("execution_time_ms", 0.0),
            now_str
        ))
        scan_id = cursor.lastrowid

        for pair in pairs:
            fa = pair.get("fragment_a", {})
            fb = pair.get("fragment_b", {})
            cursor.execute("""
                INSERT INTO clone_pairs (
                    scan_id, clone_type, similarity, token_count,
                    file_a, start_line_a, end_line_a, code_snippet_a,
                    file_b, start_line_b, end_line_b, code_snippet_b,
                    refactoring_suggestion
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                scan_id,
                pair.get("clone_type", "Unknown"),
                pair.get("similarity", 0.0),
                pair.get("token_count", 0),
                fa.get("file_path", "snippet_a"),
                fa.get("start_line", 1),
                fa.get("end_line", 1),
                fa.get("code_snippet", ""),
                fb.get("file_path", "snippet_b"),
                fb.get("start_line", 1),
                fb.get("end_line", 1),
                fb.get("code_snippet", ""),
                pair.get("refactoring_suggestion", "")
            ))

        if clusters:
            for cl in clusters:
                cursor.execute("""
                    INSERT INTO clusters (
                        scan_id, cluster_id, member_count, average_lines, summary, fragments_json
                    ) VALUES (?, ?, ?, ?, ?, ?)
                """, (
                    scan_id,
                    cl.get("cluster_id", "Cluster"),
                    cl.get("member_count", 0),
                    cl.get("average_lines", 0.0),
                    cl.get("summary", ""),
                    json.dumps(cl.get("fragments", []))
                ))

        conn.commit()
        return scan_id

def get_recent_scans(limit: int = 20, db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    """Retrieves list of recent scan records."""
    init_db(db_path)
    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT * FROM scans ORDER BY id DESC LIMIT ?
        """, (limit,))
        rows = cursor.fetchall()
        return [dict(row) for row in rows]

def get_scan_details(scan_id: int, db_path: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Retrieves full scan report including clone pairs and clusters."""
    init_db(db_path)
    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM scans WHERE id = ?", (scan_id,))
        scan_row = cursor.fetchone()
        if not scan_row:
            return None

        result = dict(scan_row)

        cursor.execute("SELECT * FROM clone_pairs WHERE scan_id = ? ORDER BY similarity DESC", (scan_id,))
        pairs = []
        for row in cursor.fetchall():
            p = dict(row)
            pairs.append({
                "id": p["id"],
                "clone_type": p["clone_type"],
                "similarity": p["similarity"],
                "token_count": p["token_count"],
                "fragment_a": {
                    "file_path": p["file_a"],
                    "start_line": p["start_line_a"],
                    "end_line": p["end_line_a"],
                    "line_count": max(1, p["end_line_a"] - p["start_line_a"] + 1),
                    "code_snippet": p["code_snippet_a"]
                },
                "fragment_b": {
                    "file_path": p["file_b"],
                    "start_line": p["start_line_b"],
                    "end_line": p["end_line_b"],
                    "line_count": max(1, p["end_line_b"] - p["start_line_b"] + 1),
                    "code_snippet": p["code_snippet_b"]
                },
                "refactoring_suggestion": p["refactoring_suggestion"]
            })
        result["clone_pairs"] = pairs

        cursor.execute("SELECT * FROM clusters WHERE scan_id = ?", (scan_id,))
        clusters = []
        for row in cursor.fetchall():
            c = dict(row)
            try:
                frags = json.loads(c["fragments_json"])
            except Exception:
                frags = []
            clusters.append({
                "cluster_id": c["cluster_id"],
                "member_count": c["member_count"],
                "average_lines": c["average_lines"],
                "summary": c["summary"],
                "fragments": frags
            })
        result["clusters"] = clusters

        return result

def delete_scan(scan_id: int, db_path: Optional[str] = None) -> bool:
    """Deletes a scan and associated records."""
    init_db(db_path)
    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM clone_pairs WHERE scan_id = ?", (scan_id,))
        cursor.execute("DELETE FROM clusters WHERE scan_id = ?", (scan_id,))
        cursor.execute("DELETE FROM scans WHERE id = ?", (scan_id,))
        conn.commit()
        return cursor.rowcount > 0

def get_db_stats(db_path: Optional[str] = None) -> Dict[str, Any]:
    """Returns database summary statistics for dashboard metrics."""
    init_db(db_path)
    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) as total_scans, SUM(clone_pairs_count) as total_clones FROM scans")
        row = cursor.fetchone()
        return {
            "total_scans": row["total_scans"] if row else 0,
            "total_clones_detected": row["total_clones"] if row and row["total_clones"] else 0,
            "database_file": db_path or DEFAULT_DB_PATH
        }
