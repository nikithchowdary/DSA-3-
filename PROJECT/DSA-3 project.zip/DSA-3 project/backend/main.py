"""
FastAPI Backend Server for Source Code Clone Detector.
Provides RESTful APIs for snippet comparison, multi-file scans, sample benchmarks,
SQLite persistence, and static frontend hosting.
"""

import os
import time
from typing import Dict, Any, List, Optional
from pathlib import Path

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse, HTMLResponse
from pydantic import BaseModel, Field

from backend.core import (
    Tokenizer, Normalizer, RabinKarpHasher,
    CloneDetector, CloneType, CloneClusterer, RefactoringEngine,
    generate_html_visual_report
)
from backend.database import (
    init_db, save_scan, get_recent_scans,
    get_scan_details, delete_scan, get_db_stats
)

BASE_DIR = Path(__file__).resolve().parent.parent
SAMPLES_DIR = BASE_DIR / "samples"
FRONTEND_DIR = BASE_DIR / "frontend"

app = FastAPI(
    title="Source Code Clone Detector",
    description="Algorithmic Clone Detection Engine using Rabin-Karp, Token Normalization, and DSU Clustering",
    version="1.0.0"
)

# Enable CORS for cross-origin frontend support
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Ensure database tables exist
init_db()

# --- Request / Response Models ---

class SnippetCompareRequest(BaseModel):
    code_a: str = Field(..., description="Source code snippet A")
    code_b: str = Field(..., description="Source code snippet B")
    language: str = Field("generic", description="Language: python, java, cpp, javascript, or generic")
    window_size: int = Field(15, ge=5, le=100, description="Rabin-Karp sliding window size")
    similarity_threshold: float = Field(0.50, ge=0.1, le=1.0, description="Clone similarity threshold (0.1 to 1.0)")
    save_to_db: bool = Field(True, description="Whether to persist this scan in SQLite")

class DirectScanRequest(BaseModel):
    files: Dict[str, str] = Field(..., description="Mapping from file_path/name to code content")
    scan_name: str = Field("Project Scan", description="Label for this scan")
    window_size: int = Field(15, ge=5, le=100)
    similarity_threshold: float = Field(0.50, ge=0.1, le=1.0)
    save_to_db: bool = Field(True)

# --- API Endpoints ---

@app.get("/api/health")
def health_check():
    return {
        "status": "online",
        "service": "Source Code Clone Detector",
        "version": "1.0.0",
        "supported_languages": ["python", "java", "cpp", "javascript", "generic"],
        "algorithms": {
            "hashing": "Rabin-Karp Rolling Hash (Mersenne prime 2^61 - 1)",
            "indexing": "Inverted Hash Table O(1) candidate lookup",
            "normalization": "Type-1 exact tokens, Type-2 parameterized identifiers & literals",
            "clustering": "Disjoint Set Union (DSU) with rank & path compression",
            "refactoring": "Template method, parameterization, and common utility extraction"
        },
        "course_metadata": {
            "course": "Database Systems Engineering and Distributed Backend Development (25CS1302E)",
            "guide": "Dr. Dyuti Banerjee",
            "team": [
                {"roll": "2520090219", "name": "V. Nikith"},
                {"roll": "2520080047", "name": "T. Harsha Vardhan"},
                {"roll": "2520090080", "name": "D. Satvarsh"}
            ]
        }
    }

@app.post("/api/detect/snippets")
def compare_snippets(req: SnippetCompareRequest):
    if not req.code_a.strip() or not req.code_b.strip():
        raise HTTPException(status_code=400, detail="Both code snippets must be non-empty.")

    detector = CloneDetector(
        window_size=req.window_size,
        similarity_threshold=req.similarity_threshold
    )

    result = detector.compare_two_snippets(
        code_a=req.code_a,
        code_b=req.code_b,
        language=req.language,
        threshold=req.similarity_threshold
    )

    # Generate automated refactoring suggestion if it's a clone
    refactoring = None
    if result.get("is_clone"):
        refactoring = RefactoringEngine.generate_refactoring({
            "clone_type": result["clone_type"],
            "fragment_a": {"file_path": "Snippet A", "start_line": 1, "end_line": len(req.code_a.splitlines()), "code_snippet": req.code_a},
            "fragment_b": {"file_path": "Snippet B", "start_line": 1, "end_line": len(req.code_b.splitlines()), "code_snippet": req.code_b}
        })
    result["refactoring"] = refactoring

    # Optionally persist in SQLite
    scan_id = None
    if req.save_to_db:
        scan_info = {
            "scan_name": f"Snippet Compare ({req.language})",
            "scan_type": "snippet",
            "language": req.language,
            "total_files": 2,
            "total_lines": len(req.code_a.splitlines()) + len(req.code_b.splitlines()),
            "cloned_files_count": 2 if result.get("is_clone") else 0,
            "cloned_lines_count": (len(req.code_a.splitlines()) + len(req.code_b.splitlines())) if result.get("is_clone") else 0,
            "duplication_percentage": result.get("similarity", 0.0) if result.get("is_clone") else 0.0,
            "execution_time_ms": result.get("execution_time_ms", 0.0),
            "clone_breakdown": {
                result["clone_type"]: 1 if result.get("is_clone") else 0
            }
        }
        pair_record = [{
            "clone_type": result["clone_type"],
            "similarity": result["similarity"],
            "token_count": result.get("token_count", 0),
            "fragment_a": {"file_path": "Snippet A", "start_line": 1, "end_line": len(req.code_a.splitlines()), "code_snippet": req.code_a},
            "fragment_b": {"file_path": "Snippet B", "start_line": 1, "end_line": len(req.code_b.splitlines()), "code_snippet": req.code_b},
            "refactoring_suggestion": result.get("refactoring_suggestion", "")
        }]
        scan_id = save_scan(scan_info, pair_record)
    
    result["saved_scan_id"] = scan_id
    return result

@app.post("/api/detect/files")
def scan_files_endpoint(req: DirectScanRequest):
    if not req.files:
        raise HTTPException(status_code=400, detail="No files provided for scan.")

    detector = CloneDetector(
        window_size=req.window_size,
        similarity_threshold=req.similarity_threshold
    )

    scan_result = detector.scan_files(req.files, threshold=req.similarity_threshold)
    
    # Cluster clone pairs using Disjoint Set Union
    clusters = CloneClusterer.build_clusters(scan_result["clone_pairs"])
    scan_result["clusters"] = clusters

    # Enrich each clone pair with refactoring proposal
    for pair in scan_result["clone_pairs"]:
        pair["refactoring"] = RefactoringEngine.generate_refactoring(pair)

    # Persist in SQLite
    scan_id = None
    if req.save_to_db:
        scan_info = {
            "scan_name": req.scan_name,
            "scan_type": "multi-file",
            "language": "multi",
            "total_files": scan_result["total_files"],
            "total_lines": scan_result["total_lines"],
            "cloned_files_count": scan_result["cloned_files_count"],
            "cloned_lines_count": scan_result["cloned_lines_count"],
            "duplication_percentage": scan_result["duplication_percentage"],
            "execution_time_ms": scan_result.get("execution_time_ms", 0.0),
            "clone_breakdown": scan_result["clone_breakdown"]
        }
        scan_id = save_scan(scan_info, scan_result["clone_pairs"], clusters)

    scan_result["saved_scan_id"] = scan_id
    return scan_result

@app.post("/api/detect/upload")
async def upload_files_endpoint(
    files: List[UploadFile] = File(...),
    window_size: int = Form(15),
    similarity_threshold: float = Form(0.50),
    scan_name: str = Form("Uploaded Files Scan")
):
    if not files:
        raise HTTPException(status_code=400, detail="No files uploaded.")

    file_contents: Dict[str, str] = {}
    for f in files:
        content_bytes = await f.read()
        try:
            content_str = content_bytes.decode("utf-8")
        except UnicodeDecodeError:
            try:
                content_str = content_bytes.decode("latin-1")
            except Exception:
                continue
        file_contents[f.filename] = content_str

    if not file_contents:
        raise HTTPException(status_code=400, detail="Unable to read uploaded text/code files.")

    detector = CloneDetector(window_size=window_size, similarity_threshold=similarity_threshold)
    scan_result = detector.scan_files(file_contents, threshold=similarity_threshold)
    clusters = CloneClusterer.build_clusters(scan_result["clone_pairs"])
    scan_result["clusters"] = clusters

    for pair in scan_result["clone_pairs"]:
        pair["refactoring"] = RefactoringEngine.generate_refactoring(pair)

    scan_info = {
        "scan_name": scan_name,
        "scan_type": "multi-file",
        "language": "multi",
        "total_files": scan_result["total_files"],
        "total_lines": scan_result["total_lines"],
        "cloned_files_count": scan_result["cloned_files_count"],
        "cloned_lines_count": scan_result["cloned_lines_count"],
        "duplication_percentage": scan_result["duplication_percentage"],
        "execution_time_ms": scan_result.get("execution_time_ms", 0.0),
        "clone_breakdown": scan_result["clone_breakdown"]
    }
    scan_id = save_scan(scan_info, scan_result["clone_pairs"], clusters)
    scan_result["saved_scan_id"] = scan_id
    return scan_result

@app.get("/api/samples")
def list_samples():
    """Returns curated benchmark samples with code content and category metadata."""
    sample_categories = []

    for lang in ["python", "java", "cpp", "javascript"]:
        lang_dir = SAMPLES_DIR / lang
        if not lang_dir.exists():
            continue

        files_info = []
        for file_path in sorted(lang_dir.iterdir()):
            if file_path.is_file() and not file_path.name.startswith("."):
                with open(file_path, "r", encoding="utf-8") as f:
                    code = f.read()
                
                # Infer sample tag
                name_lower = file_path.name.lower()
                if "original" in name_lower:
                    category_tag = "Original / Baseline"
                elif "type1" in name_lower:
                    category_tag = "Type-1 (Exact)"
                elif "type2" in name_lower:
                    category_tag = "Type-2 (Renamed)"
                elif "type3" in name_lower:
                    category_tag = "Type-3 (Near-Miss)"
                elif "control" in name_lower:
                    category_tag = "Control (Non-Clone)"
                else:
                    category_tag = "Sample"

                files_info.append({
                    "filename": file_path.name,
                    "rel_path": str(file_path.relative_to(BASE_DIR)),
                    "language": lang,
                    "category": category_tag,
                    "line_count": len(code.splitlines()),
                    "code": code
                })

        sample_categories.append({
            "language": lang,
            "title": f"{lang.capitalize()} Test Suite",
            "files": files_info
        })

    return {"categories": sample_categories}

@app.get("/api/history")
def history_list(limit: int = Query(25, ge=1, le=100)):
    """Returns list of past scans from SQLite."""
    return {"scans": get_recent_scans(limit=limit)}

@app.get("/api/history/{scan_id}")
def history_detail(scan_id: int):
    """Returns full scan report by ID."""
    details = get_scan_details(scan_id)
    if not details:
        raise HTTPException(status_code=404, detail="Scan record not found.")
    return details

@app.delete("/api/history/{scan_id}")
def history_delete(scan_id: int):
    """Deletes a scan report by ID."""
    deleted = delete_scan(scan_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Scan record not found.")
    return {"success": True, "deleted_id": scan_id}

@app.get("/api/stats")
def database_stats():
    """Returns aggregated database statistics."""
    return get_db_stats()

@app.get("/api/report/html/{scan_id}", response_class=HTMLResponse)
def get_html_report(scan_id: int, download: bool = False):
    """Generates and returns standalone visual HTML report for a scan."""
    details = get_scan_details(scan_id)
    if not details:
        raise HTTPException(status_code=404, detail="Scan record not found.")
    html_content = generate_html_visual_report(details, title=f"Clone Report #{scan_id} - {details.get('scan_name', '')}")
    headers = {}
    if download:
        headers["Content-Disposition"] = f"attachment; filename=clone_report_{scan_id}.html"
    return HTMLResponse(content=html_content, headers=headers)

@app.post("/api/report/generate-html", response_class=HTMLResponse)
def generate_html_report_direct(data: Dict[str, Any]):
    """Generates standalone visual HTML report on-demand from scan data."""
    html_content = generate_html_visual_report(data, title=f"Visual Clone Report - {data.get('scan_name', 'Audit')}")
    return HTMLResponse(content=html_content)

# Mount Frontend static files if directory exists
if FRONTEND_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")

    @app.get("/")
    def serve_frontend():
        index_file = FRONTEND_DIR / "index.html"
        if index_file.exists():
            return FileResponse(str(index_file))
        return JSONResponse({"message": "Frontend index.html not found"}, status_code=404)
