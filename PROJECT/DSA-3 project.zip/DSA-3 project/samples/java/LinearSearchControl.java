// Non-Clone Control Sample in Java
public class LinearSearchControl {
    public static int linearSearch(int[] numbers, int key) {
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] == key) {
                return i;
            }
        }
        return -1;
    }

    public static int findMinimum(int[] numbers) {
        int min = numbers[0];
        for (int val : numbers) {
            if (val < min) {
                min = val;
            }
        }
        return min;
    }
}
