// Type-1 Exact Clone with different indentation and comments
public class BinarySearchType1 {
    /**
     * Standard implementation of logarithmic search
     */
    public static int binarySearch(int[] arr, int target) 
    {
        int low = 0;
        int high = arr.length - 1;

        while (low <= high) 
        {
            int mid = low + (high - low) / 2;

            if (arr[mid] == target) 
            {
                return mid;
            } 
            else if (arr[mid] < target) 
            {
                low = mid + 1;
            } 
            else 
            {
                high = mid - 1;
            }
        }
        return -1;
    }
}
