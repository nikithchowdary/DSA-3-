// Type-2 Renamed / Parameterized Clone
public class BinarySearchType2 {
    public static int findElement(int[] items, int key) {
        int left = 0;
        int right = items.length - 1;

        while (left <= right) {
            int center = left + (right - left) / 2;

            if (items[center] == key) {
                return center;
            } else if (items[center] < key) {
                left = center + 1;
            } else {
                right = center - 1;
            }
        }
        return -1;
    }
}
