# Type-1 Exact Clone of bubble_sort
# Different comment header and internal remarks

def bubble_sort(arr):
    # Determine the length of array
    n = len(arr)

    for i in range(n):
        swapped = False

        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                temp = arr[j]
                arr[j] = arr[j + 1]
                arr[j + 1] = temp
                swapped = True

        # Check if already sorted
        if not swapped:
            break

    return arr

def display_array(arr):
    # Output list values
    print("Array elements:", arr)
