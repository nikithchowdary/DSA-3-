def bubble_sort_advanced(arr):
    # Added validation check
    if not arr or len(arr) <= 1:
        return arr

    n = len(arr)
    comparisons = 0

    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            comparisons += 1
            if arr[j] > arr[j + 1]:
                temp = arr[j]
                arr[j] = arr[j + 1]
                arr[j + 1] = temp
                swapped = True
        if not swapped:
            break

    print(f"Total comparisons executed: {comparisons}")
    return arr
