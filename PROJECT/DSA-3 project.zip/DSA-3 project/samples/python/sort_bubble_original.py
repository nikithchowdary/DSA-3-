def bubble_sort(arr):
    """
    Standard bubble sort implementation in Python.
    Sorts a list of numbers in ascending order.
    """
    n = len(arr)
    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                temp = arr[j]
                arr[j] = arr[j + 1]
                arr[j + 1] = temp
                swapped = True
        if not swapped:
            break
    return arr

def display_array(arr):
    print("Array elements:", arr)
