def bubble_sort_custom(items):
    size = len(items)
    for step in range(size):
        has_exchanged = False
        for idx in range(0, size - step - 1):
            if items[idx] > items[idx + 1]:
                holding_val = items[idx]
                items[idx] = items[idx + 1]
                items[idx + 1] = holding_val
                has_exchanged = True
        if not has_exchanged:
            break
    return items

def print_collection(elements):
    print("Collection items:", elements)
