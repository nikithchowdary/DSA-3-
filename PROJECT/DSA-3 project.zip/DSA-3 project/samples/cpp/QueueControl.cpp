// Non-Clone Control Sample: Queue using Linked List (C++)
// Structurally distinct from Stack — uses nodes, head/tail pointers, and FIFO
// traversal.
#include <iostream>
#include <stdexcept>

struct Node {
  int data;
  Node *next;
  Node(int d) : data(d), next(nullptr) {}
};

class LinkedQueue {
  Node *head;
  Node *tail;
  int count;

public:
  LinkedQueue() : head(nullptr), tail(nullptr), count(0) {}

  ~LinkedQueue() {
    while (head != nullptr) {
      Node *tmp = head;
      head = head->next;
      delete tmp;
    }
  }

  void enqueue(int value) {
    Node *node = new Node(value);
    if (tail != nullptr) {
      tail->next = node;
    }
    tail = node;
    if (head == nullptr) {
      head = node;
    }
    count++;
  }

  int dequeue() {
    if (head == nullptr) {
      throw std::underflow_error("Queue underflow: no elements to dequeue");
    }
    int result = head->data;
    Node *old = head;
    head = head->next;
    if (head == nullptr) {
      tail = nullptr;
    }
    delete old;
    count--;
    return result;
  }

  int peek() const {
    if (head == nullptr) {
      throw std::underflow_error("Queue is empty");
    }
    return head->data;
  }

  bool isEmpty() const { return count == 0; }

  int size() const { return count; }

  void printAll() const {
    Node *cur = head;
    while (cur != nullptr) {
      std::cout << cur->data;
      if (cur->next != nullptr)
        std::cout << " -> ";
      cur = cur->next;
    }
    std::cout << std::endl;
  }
};

int main() {
  LinkedQueue q;
  for (int i = 1; i <= 5; i++) {
    q.enqueue(i * 10);
  }
  std::cout << "Queue: ";
  q.printAll();
  std::cout << "Dequeued: " << q.dequeue() << std::endl;
  std::cout << "Front: " << q.peek() << std::endl;
  std::cout << "Size: " << q.size() << std::endl;
  return 0;
}
