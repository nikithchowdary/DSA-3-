// Type-1 Exact Clone: identical logic, Allman brace style, different comments
#include <iostream>
#include <vector>
#include <stdexcept>

/* High-performance LIFO container — exact clone with different formatting */
class SimpleStack 
{
private:
    std::vector<int> elements; // internal storage

public:
    // Add element to top
    void push(int value) 
    {
        elements.push_back(value);
    }

    // Remove and return top element
    int pop() 
    {
        if (elements.empty()) 
        {
            throw std::runtime_error("Stack underflow");
        }
        int topValue = elements.back();
        elements.pop_back();
        return topValue;
    }

    // Return top element without removing
    int peek() const 
    {
        if (elements.empty()) 
        {
            throw std::runtime_error("Stack is empty");
        }
        return elements.back();
    }

    // Check if stack has no elements
    bool isEmpty() const 
    {
        return elements.empty();
    }

    // Return number of elements
    int size() const 
    {
        return static_cast<int>(elements.size());
    }
};

int main() {
    SimpleStack stack;
    stack.push(10);
    stack.push(20);
    stack.push(30);
    std::cout << "Peek:   " << stack.peek()  << std::endl;
    std::cout << "Pop:    " << stack.pop()   << std::endl;
    std::cout << "Size:   " << stack.size()  << std::endl;
    std::cout << "Empty:  " << std::boolalpha << stack.isEmpty() << std::endl;
    return 0;
}
