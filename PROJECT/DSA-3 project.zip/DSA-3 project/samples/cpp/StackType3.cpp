// Type-3 Near-Miss Clone with added capacity check and peek in C++
#include <iostream>
#include <vector>
#include <stdexcept>

class SimpleStack {
private:
    std::vector<int> elements;
    size_t maxCapacity = 1000;

public:
    void push(int value) {
        if (elements.size() >= maxCapacity) {
            throw std::runtime_error("Stack overflow capacity exceeded");
        }
        elements.push_back(value);
    }

    int pop() {
        if (elements.empty()) {
            throw std::runtime_error("Stack underflow");
        }
        int topValue = elements.back();
        elements.pop_back();
        return topValue;
    }

    int peek() const {
        if (elements.empty()) {
            throw std::runtime_error("Stack is empty");
        }
        return elements.back();
    }

    bool isEmpty() const {
        return elements.empty();
    }

    int size() const {
        return static_cast<int>(elements.size());
    }
};

int main() {
    SimpleStack s;
    s.push(10);
    s.push(20);
    s.push(30);
    std::cout << "Peek: "   << s.peek()    << std::endl;
    std::cout << "Popped: " << s.pop()     << std::endl;
    std::cout << "Size: "   << s.size()    << std::endl;
    std::cout << "Empty: "  << std::boolalpha << s.isEmpty() << std::endl;
    return 0;
}
