#include <iostream>
#include <vector>
#include <stdexcept>

class SimpleStack {
private:
    std::vector<int> elements;

public:
    void push(int value) {
        elements.push_back(value);
    }

    int pop() {
        if (elements.empty()) {
            throw std::runtime_error("Stack underflow");
        }
        int topValue = elements.back();
        elements.pop_back();
        return topValue;
    }

    int peek() const {
        if (elements.empty()) {
            throw std::runtime_error("Stack is empty");
        }
        return elements.back();
    }

    bool isEmpty() const {
        return elements.empty();
    }

    int size() const {
        return static_cast<int>(elements.size());
    }
};

int main() {
    SimpleStack stack;
    stack.push(10);
    stack.push(20);
    stack.push(30);
    std::cout << "Peek:   " << stack.peek()  << std::endl;
    std::cout << "Pop:    " << stack.pop()   << std::endl;
    std::cout << "Size:   " << stack.size()  << std::endl;
    std::cout << "Empty:  " << std::boolalpha << stack.isEmpty() << std::endl;
    return 0;
}
