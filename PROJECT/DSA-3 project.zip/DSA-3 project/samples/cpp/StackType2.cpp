#include <iostream>
#include <vector>
#include <stdexcept>

class CustomStackContainer {
private:
    std::vector<int> storageList;

public:
    void insertElement(int item) {
        storageList.push_back(item);
    }

    int extractElement() {
        if (storageList.empty()) {
            throw std::runtime_error("Stack underflow");
        }
        int retrieved = storageList.back();
        storageList.pop_back();
        return retrieved;
    }

    bool hasNoElements() const {
        return storageList.empty();
    }

    int peekTop() const {
        if (storageList.empty()) {
            throw std::runtime_error("Stack is empty");
        }
        return storageList.back();
    }

    int currentSize() const {
        return static_cast<int>(storageList.size());
    }
};

int main() {
    CustomStackContainer s;
    s.insertElement(10);
    s.insertElement(20);
    s.insertElement(30);
    std::cout << "Top: " << s.peekTop() << std::endl;
    std::cout << "Popped: " << s.extractElement() << std::endl;
    std::cout << "Size: " << s.currentSize() << std::endl;
    std::cout << "Empty: " << std::boolalpha << s.hasNoElements() << std::endl;
    return 0;
}
