// Control Sample: Distinct Linear Search logic (Non-Clone Control)
function linearSearch(arr, target) {
    for (let idx = 0; idx < arr.length; idx++) {
        if (arr[idx] === target) {
            return idx;
        }
    }
    return -1;
}

function countOccurrences(collection, item) {
    let count = 0;
    for (const element of collection) {
        if (element === item) {
            count++;
        }
    }
    return count;
}
