// Type-2 Renamed Clone: Identical syntactic structure with renamed identifiers
function combineLists(firstHalf, secondHalf) {
    let merged = [];
    let p1 = 0;
    let p2 = 0;

    while (p1 < firstHalf.length && p2 < secondHalf.length) {
        if (firstHalf[p1] <= secondHalf[p2]) {
            merged.push(firstHalf[p1]);
            p1++;
        } else {
            merged.push(secondHalf[p2]);
            p2++;
        }
    }

    while (p1 < firstHalf.length) {
        merged.push(firstHalf[p1]);
        p1++;
    }

    while (p2 < secondHalf.length) {
        merged.push(secondHalf[p2]);
        p2++;
    }

    return merged;
}

function divideAndConquerSort(items) {
    if (items.length <= 1) {
        return items;
    }
    const center = Math.floor(items.length / 2);
    const subLeft = divideAndConquerSort(items.slice(0, center));
    const subRight = divideAndConquerSort(items.slice(center));
    return combineLists(subLeft, subRight);
}
