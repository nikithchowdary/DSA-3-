// Type-3 Near-Miss Clone: Statements modified, logging added, edge validation inserted
function merge(left, right) {
    if (!left || !right) {
        return [];
    }
    let result = [];
    let i = 0;
    let j = 0;

    while (i < left.length && j < right.length) {
        if (left[i] <= right[j]) {
            result.push(left[i]);
            i++;
        } else {
            result.push(right[j]);
            j++;
        }
    }

    while (i < left.length) {
        result.push(left[i]);
        i++;
    }

    while (j < right.length) {
        result.push(right[j]);
        j++;
    }

    console.log("Merged sub-arrays successfully:", result.length);
    return result;
}

function mergeSort(arr) {
    if (!Array.isArray(arr) || arr.length <= 1) {
        return arr;
    }
    const mid = Math.floor(arr.length / 2);
    const left = mergeSort(arr.slice(0, mid));
    const right = mergeSort(arr.slice(mid));
    return merge(left, right);
}
