// Type-1 Exact Clone: Identical token sequence, differing only in comments and formatting
/* Standard Two-Way Merge Sort Algorithm */
function merge(left, right) 
{
    let result = [];
    let i = 0;
    let j = 0;

    // Compare and merge elements
    while (i < left.length && j < right.length) 
    {
        if (left[i] <= right[j]) 
        {
            result.push(left[i]);
            i++;
        } 
        else 
        {
            result.push(right[j]);
            j++;
        }
    }

    // Append remaining elements from left
    while (i < left.length) 
    {
        result.push(left[i]);
        i++;
    }

    // Append remaining elements from right
    while (j < right.length) 
    {
        result.push(right[j]);
        j++;
    }

    return result;
}

function mergeSort(arr) 
{
    if (arr.length <= 1) 
    {
        return arr;
    }
    const mid = Math.floor(arr.length / 2);
    const left = mergeSort(arr.slice(0, mid));
    const right = mergeSort(arr.slice(mid));
    return merge(left, right);
}
