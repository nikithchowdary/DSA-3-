#!/usr/bin/env python3
"""
Source Code Clone Detector - Quick Launcher
Starts the FastAPI backend and opens the interactive dashboard in the default browser.
"""

import os
import sys
import webbrowser
import threading
import time
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

def open_dashboard(port: int = 8000):
    time.sleep(1.2)
    url = f"http://localhost:{port}"
    print(f"\n[Launcher] Opening Clone Detector Dashboard: {url}")
    try:
        webbrowser.open(url)
    except Exception as e:
        print(f"[Launcher] Could not automatically open browser: {e}")

def is_port_in_use(port: int, host: str = "127.0.0.1") -> bool:
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex((host, port)) == 0

def find_available_port(start_port: int = 8000, host: str = "127.0.0.1") -> int:
    port = start_port
    while is_port_in_use(port, host):
        port += 1
    return port

def main():
    print("""
========================================================================
   STARTING SOURCE CODE CLONE DETECTOR SERVER
   DSA-3 Project (25CS1302E) • Sec 13 / Team 02
   Guide: Dr. Dyuti Banerjee
========================================================================
    """)

    requested_port = int(os.environ.get("PORT", 8000))
    host = os.environ.get("HOST", "127.0.0.1")
    
    port = find_available_port(requested_port, host)
    if port != requested_port:
        print(f"[Launcher] Note: Port {requested_port} is busy. Automatically switching to port {port}.")

    # Start browser in background thread
    threading.Thread(target=open_dashboard, args=(port,), daemon=True).start()

    try:
        import uvicorn
        uvicorn.run("backend.main:app", host=host, port=port, reload=False, log_level="info")
    except KeyboardInterrupt:
        print("\n[Launcher] Server stopped cleanly. Goodbye!")
    except OSError as e:
        print(f"\n[Launcher] Network/Port error: {e}")
    except Exception as e:
        print(f"\n[Launcher] Unexpected error starting server: {e}")

if __name__ == "__main__":
    main()
