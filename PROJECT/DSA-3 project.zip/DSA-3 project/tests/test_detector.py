"""
Comprehensive Automated Test Suite for Source Code Clone Detector.
Validates Tokenizer, Normalizer, Rabin-Karp Hasher, Clone Detector, DSU Clusterer,
Refactoring Engine, and SQLite Database persistence.
"""

import unittest
import os
import tempfile
from pathlib import Path

from backend.core import (
    Tokenizer, Token, TokenType,
    Normalizer, RabinKarpHasher,
    CloneDetector, CloneType,
    CloneClusterer, RefactoringEngine,
    generate_html_visual_report
)
from backend.database import init_db, save_scan, get_recent_scans, get_scan_details, delete_scan

class TestTokenizer(unittest.TestCase):
    def test_language_detection(self):
        self.assertEqual(Tokenizer.detect_language("script.py"), "python")
        self.assertEqual(Tokenizer.detect_language("Main.java"), "java")
        self.assertEqual(Tokenizer.detect_language("algo.cpp"), "cpp")
        self.assertEqual(Tokenizer.detect_language("server.js"), "javascript")
        self.assertEqual(Tokenizer.detect_language("unknown.txt"), "generic")

    def test_python_tokenization(self):
        code = "# Header comment\ndef calculate(x, y):\n    return x + y * 10\n"
        tokens = Tokenizer.tokenize(code, "python")
        token_values = [t.value for t in tokens]
        
        self.assertIn("def", token_values)
        self.assertIn("calculate", token_values)
        self.assertIn("return", token_values)
        self.assertIn("+", token_values)
        self.assertIn("*", token_values)
        self.assertIn("10", token_values)
        
        # Comments should be discarded
        self.assertNotIn("# Header comment", token_values)

    def test_java_tokenization(self):
        code = "/* Block comment */ public static int search(int[] arr) { return -1; }"
        tokens = Tokenizer.tokenize(code, "java")
        types = [t.type for t in tokens]
        
        self.assertIn(TokenType.KEYWORD, types)
        self.assertIn(TokenType.IDENTIFIER, types)
        self.assertIn(TokenType.DELIMITER, types)

    def test_javascript_tokenization(self):
        code = "// JS Single line\nconst merge = (a, b) => { return `merged: ${a}`; };"
        tokens = Tokenizer.tokenize(code, "javascript")
        values = [t.value for t in tokens]
        self.assertIn("const", values)
        self.assertIn("return", values)
        self.assertIn("merge", values)

    def test_cpp_tokenization(self):
        code = "/* C++ stack */ class Stack { public: void push(int val); };"
        tokens = Tokenizer.tokenize(code, "cpp")
        values = [t.value for t in tokens]
        self.assertIn("class", values)
        self.assertIn("public", values)
        self.assertIn("void", values)
        self.assertIn("int", values)

class TestNormalizer(unittest.TestCase):
    def test_type1_normalization(self):
        code = "def foo(a):\n    return a"
        tokens = Tokenizer.tokenize(code, "python")
        norm = Normalizer.normalize_type1(tokens)
        self.assertEqual(norm, ["def", "foo", "(", "a", ")", ":", "return", "a"])

    def test_type2_normalization(self):
        code = "def compute_sum(val1, val2):\n    return val1 + val2 + 42"
        tokens = Tokenizer.tokenize(code, "python")
        norm, id_map = Normalizer.normalize_type2(tokens)
        
        self.assertEqual(norm[0], "def")
        self.assertTrue(norm[1].startswith("$VAR_"))
        self.assertEqual(norm[-1], "$NUM")

class TestRabinKarpHasher(unittest.TestCase):
    def test_rolling_hash_consistency(self):
        tokens = ["for", "i", "in", "range", "(", "n", ")", ":", "print", "(", "i", ")"]
        hasher = RabinKarpHasher(window_size=5)
        hashes = hasher.compute_hashes(tokens)
        
        self.assertEqual(len(hashes), len(tokens) - 5 + 1)
        for hval, s_idx, e_idx in hashes:
            self.assertEqual(e_idx - s_idx, 5)
            self.assertIsInstance(hval, int)

    def test_insufficient_tokens(self):
        hasher = RabinKarpHasher(window_size=10)
        hashes = hasher.compute_hashes(["a", "b", "c"])
        self.assertEqual(hashes, [])

class TestCloneDetector(unittest.TestCase):
    def setUp(self):
        self.detector = CloneDetector(window_size=10, similarity_threshold=0.50)

    def test_type1_exact_clone(self):
        code_a = "def sort(arr):\n    # Sort array\n    return sorted(arr)"
        code_b = "def sort(arr):\n    # Different comment\n    return sorted(arr)"
        res = self.detector.compare_two_snippets(code_a, code_b, "python")
        
        self.assertTrue(res["is_clone"])
        self.assertEqual(res["clone_type"], CloneType.TYPE_1)
        self.assertEqual(res["similarity"], 100.0)

    def test_type2_renamed_clone(self):
        code_a = "def find_max(numbers):\n    m = numbers[0]\n    for num in numbers:\n        if num > m:\n            m = num\n    return m"
        code_b = "def get_highest(items):\n    top = items[0]\n    for element in items:\n        if element > top:\n            top = element\n    return top"
        res = self.detector.compare_two_snippets(code_a, code_b, "python")
        
        self.assertTrue(res["is_clone"])
        self.assertEqual(res["clone_type"], CloneType.TYPE_2)
        self.assertEqual(res["similarity"], 100.0)

    def test_type3_near_miss_clone(self):
        code_a = "def process(lst):\n    total = 0\n    for x in lst:\n        total += x\n    return total"
        code_b = "def process(lst):\n    if not lst: return 0\n    total = 0\n    for x in lst:\n        total += x\n    print('Total is:', total)\n    return total"
        res = self.detector.compare_two_snippets(code_a, code_b, "python")
        
        self.assertTrue(res["is_clone"])
        self.assertEqual(res["clone_type"], CloneType.TYPE_3)
        self.assertGreaterEqual(res["similarity"], 50.0)

    def test_non_clone_control(self):
        code_a = "def factorial(n):\n    if n <= 1: return 1\n    return n * factorial(n - 1)"
        code_b = "class Stack:\n    def __init__(self): self.items = []\n    def push(self, x): self.items.append(x)"
        res = self.detector.compare_two_snippets(code_a, code_b, "python")
        
        self.assertFalse(res["is_clone"])
        self.assertEqual(res["clone_type"], CloneType.NON_CLONE)

    def test_multi_file_scan(self):
        files = {
            "file_a.py": "def add(a, b):\n    return a + b\n",
            "file_b.py": "def add(a, b):\n    return a + b\n",
            "file_c.py": "def multiply(x, y):\n    return x * y\n"
        }
        res = self.detector.scan_files(files)
        self.assertEqual(res["total_files"], 3)
        self.assertGreaterEqual(res["clone_pairs_count"], 1)

class TestDSUClusterer(unittest.TestCase):
    def test_clustering_components(self):
        pairs = [
            {
                "fragment_a": {"file_path": "a.py", "start_line": 1, "end_line": 10},
                "fragment_b": {"file_path": "b.py", "start_line": 1, "end_line": 10}
            },
            {
                "fragment_a": {"file_path": "b.py", "start_line": 1, "end_line": 10},
                "fragment_b": {"file_path": "c.py", "start_line": 1, "end_line": 10}
            }
        ]
        clusters = CloneClusterer.build_clusters(pairs)
        self.assertEqual(len(clusters), 1)
        self.assertEqual(clusters[0]["member_count"], 3)

class TestRefactoringEngine(unittest.TestCase):
    def test_refactoring_generation(self):
        pair = {
            "clone_type": CloneType.TYPE_1,
            "fragment_a": {"file_path": "a.py", "start_line": 1, "end_line": 5, "code_snippet": "x = 1"},
            "fragment_b": {"file_path": "b.py", "start_line": 1, "end_line": 5, "code_snippet": "x = 1"}
        }
        advice = RefactoringEngine.generate_refactoring(pair)
        self.assertIn("Extract Method", advice["title"])
        self.assertIn("Low", advice["effort"])

class TestDatabasePersistence(unittest.TestCase):
    def setUp(self):
        self.temp_db = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.db_path = self.temp_db.name
        self.temp_db.close()
        init_db(self.db_path)

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    def test_save_and_retrieve_scan(self):
        scan_id = save_scan(
            {"scan_name": "Unit Test Run", "scan_type": "snippet", "language": "python", "duplication_percentage": 75.0},
            [{"clone_type": "Type-1 (Exact)", "similarity": 100.0, "fragment_a": {}, "fragment_b": {}}],
            db_path=self.db_path
        )
        self.assertIsInstance(scan_id, int)
        
        recent = get_recent_scans(limit=10, db_path=self.db_path)
        self.assertEqual(len(recent), 1)
        self.assertEqual(recent[0]["scan_name"], "Unit Test Run")
        
        details = get_scan_details(scan_id, db_path=self.db_path)
        self.assertIsNotNone(details)
        self.assertEqual(len(details["clone_pairs"]), 1)
        
        deleted = delete_scan(scan_id, db_path=self.db_path)
        self.assertTrue(deleted)
        self.assertEqual(len(get_recent_scans(limit=10, db_path=self.db_path)), 0)

class TestVisualReport(unittest.TestCase):
    def test_visual_report_generation(self):
        scan_data = {
            "scan_name": "Test Benchmark Scan",
            "scan_type": "multi-file",
            "language": "multi",
            "total_files": 2,
            "total_lines": 50,
            "cloned_files_count": 2,
            "cloned_lines_count": 40,
            "duplication_percentage": 80.0,
            "execution_time_ms": 3.5,
            "clone_breakdown": {"Type-1": 1, "Type-2": 0, "Type-3": 0},
            "clone_pairs": [{
                "clone_type": "Type-1 (Exact)",
                "similarity": 100.0,
                "token_count": 45,
                "fragment_a": {"file_path": "a.py", "start_line": 1, "end_line": 20, "code_snippet": "print(1)"},
                "fragment_b": {"file_path": "b.py", "start_line": 1, "end_line": 20, "code_snippet": "print(1)"},
                "refactoring_suggestion": "Extract common utility function"
            }],
            "clusters": []
        }
        report_html = generate_html_visual_report(scan_data)
        self.assertIn("<!DOCTYPE html>", report_html)
        self.assertIn("Test Benchmark Scan", report_html)
        self.assertIn("Type-1 (Exact)", report_html)
        self.assertIn("100.0% Match", report_html)
        self.assertIn("a.py", report_html)
        self.assertIn("b.py", report_html)

if __name__ == "__main__":
    unittest.main()
