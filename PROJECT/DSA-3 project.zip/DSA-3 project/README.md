# Source Code Clone Detector

> **Course:** Database Systems Engineering and Distributed Backend Development (25CS1302E)  
> **Trimester:** Y25 - 2026-2027 Trimester - 4 | **Section:** 13 | **Team:** 02  
> **Faculty Guide:** Dr. Dyuti Banerjee  
> **Team Members:**
> - **V. Nikith** (Roll: 2520090219)
> - **T. Harsha Vardhan** (Roll: 2520080047)
> - **D. Satvarsh** (Roll: 2520090080)

---

## 📌 Abstract & Motivation

Code cloning—copying and pasting code fragments with minor or no modifications—is one of the most common causes of code bloat, elevated maintenance overhead, and bug propagation in software engineering. 

**Source Code Clone Detector** is an algorithmic and backend-engineered platform designed to identify, classify, visualize, cluster, and refactor code clones across multi-language codebases (Python, Java, C++, and JavaScript). The system pairs algorithmic optimization (Rabin-Karp sliding window polynomial rolling hashes and Disjoint Set Union clustering) with a high-performance FastAPI backend, SQLite database persistence, and an interactive dark-mode glassmorphic dashboard.

---

## 🎯 Core Project Objectives

- **Objective 1:** Design a token-based clone detection engine that works across multiple programming languages (Python, Java, C++, JavaScript).
- **Objective 2:** Classify detected clones into **Type-1 (exact)**, **Type-2 (renamed)**, and **Type-3 (near-miss)** categories with similarity scoring.
- **Objective 3:** Provide a simple, visual report highlighting clone pairs, similarity percentage, locations, and side-by-side code diffs.

---

## 🔬 Clone Taxonomy Covered

| Clone Category | Definition | Detection Mechanism | Suggested Refactoring |
| :--- | :--- | :--- | :--- |
| **Type-1 (Exact)** | Identical token sequences; variations only in whitespace, comments, or class bindings. | Exact Lexical Token Stream Match | Extract Method / Shared Utility Function |
| **Type-2 (Renamed)** | Syntactically identical structure with renamed identifiers (variables/functions) or literals. | Isomorphic structural token match + Token Parameterization (`$VAR_i`, `$NUM`, `$STR`) | Parameterize Method / Method Unification |
| **Type-3 (Near-Miss)** | Similar code fragments where statements have been inserted, deleted, or altered. | Hybrid Metric: $50\%$ Token Sequence + $30\%$ N-gram Jaccard + $20\%$ Line Ratio | Template Method / Strategy Pattern |
| **Non-Clone** | Distinct algorithmic logic below the similarity threshold. | Similarity score falls below active threshold | No refactoring needed |

---

## 🧠 Data Structures & Algorithmic Foundations

### 1. Rabin-Karp Polynomial Rolling Hasher
Instead of naive pairwise substring comparisons which take $O(N \cdot M)$ time, sliding token windows of length $k$ are converted into integer hashes. When the window slides forward by one token, the new hash is computed in $O(1)$ constant time:

$$H_{new} = \left( (H_{old} - \text{val}_{out} \cdot B^{k-1}) \cdot B + \text{val}_{in} \right) \pmod{M}$$

- **Modulus ($M$):** $2^{61} - 1$ (Mersenne prime), delivering 64-bit precision with near-zero collisions.
- **Base ($B$):** $1,000,003$ (large prime multiplier).

### 2. Inverted Hash Index ($O(1)$ Candidate Retrieval)
Token window hashes are indexed in a hash table:
$$\text{Index}: \text{hash} \longrightarrow [(\text{file\_path}, \text{start\_token}, \text{end\_token})]$$
Colliding hash keys reveal clone candidates instantly across hundreds of files without quadratic cross-comparisons.

### 3. Disjoint Set Union (DSU) Clone Clustering
Interconnected clone pairs are grouped into global **Clone Equivalence Classes**:
- **Path Compression:** Nodes in `find(x)` point directly to their representative root, flattening the tree depth.
- **Union by Rank:** Always links shallower trees under the root of deeper trees.
- **Amortized Time:** $O(M \cdot \alpha(N)) \approx O(M)$ where $\alpha$ is the Inverse Ackermann function ($\alpha(N) < 5$).

### 4. Complexity Benchmark Comparison

| Operation | Naive Baseline | Antigravity Clone Detector | Speedup / Advantage |
| :--- | :--- | :--- | :--- |
| **Window Hashing** | $O(k)$ per window | $O(1)$ rolling slide | $k\times$ reduction |
| **Cross-File Search** | $O(F^2 \cdot L_1 \cdot L_2)$ | $O(F \cdot L)$ inverted index | Scales to large codebases |
| **Cluster Assembly** | $O(V^3)$ All-Pairs Shortest Path | $O(E \cdot \alpha(V))$ DSU | Real-time global clustering |

---

## 🏗️ Architecture & Technology Stack

```
[ Interactive Web Dashboard ]   <-->   [ Terminal CLI Tool ]
            │                                    │
            ▼                                    ▼
┌───────────────────────────────────────────────────────────┐
│                    FastAPI Backend :8000                  │
├─────────────────────────┬─────────────────────────────────┤
│    Algorithm Core       │       Persistence Layer         │
│  - Multi-Lang Tokenizer │  - SQLite clones.db             │
│  - Token Normalizer     │  - Scans Table                  │
│  - Rabin-Karp Hasher    │  - Clone Pairs Table            │
│  - Clone Detector       │  - DSU Clusters Table           │
│  - DSU Clusterer        │                                 │
│  - Refactoring Engine   │                                 │
└─────────────────────────┴─────────────────────────────────┘
```

- **Backend Framework:** FastAPI, Uvicorn, Pydantic, HTTPX.
- **Persistence Engine:** SQLite3 (Zero-config embedded relational database).
- **Frontend UI:** Vanilla HTML5, CSS3 Glassmorphism, ES6 JavaScript.
- **Supported Languages:** Python, Java, C++, JavaScript, and Generic.

---

## 🚀 Quick Start Guide

### 1. Prerequisites & Virtual Environment
Ensure you have Python 3.10+ installed. Activate the project environment:
```bash
# Activate existing environment
source venv/bin/activate

# Install required dependencies
pip install -r backend/requirements.txt
```

### 2. Launch the Web Dashboard (One Command)
```bash
python run.py
```
This automatically starts the FastAPI server at `http://127.0.0.1:8000` and launches the dashboard in your default web browser.

### 3. Command-Line Interface (CLI)
You can also run all clone detection operations directly from your terminal:

```bash
# Compare two code files directly
python cli.py compare samples/python/sort_bubble_original.py samples/python/sort_bubble_type1.py

# Compare with custom threshold
python cli.py compare samples/python/sort_bubble_original.py samples/python/sort_bubble_type3.py --threshold 50

# Scan an entire repository directory
python cli.py scan samples/python/

# View past scan history in SQLite
python cli.py history

# Run the test suite
python cli.py test
```

---

## 🧪 Automated Test Suite

Run the full automated test suite covering all algorithmic components and database operations:
```bash
python -m unittest discover -s tests -p "test_*.py"
```
**Test Coverage:**
- `test_language_detection`, `test_python_tokenization`, `test_java_tokenization`
- `test_type1_normalization`, `test_type2_normalization`
- `test_rolling_hash_consistency`, `test_insufficient_tokens`
- `test_type1_exact_clone`, `test_type2_renamed_clone`, `test_type3_near_miss_clone`, `test_non_clone_control`, `test_multi_file_scan`
- `test_clustering_components` (DSU rank and path compression)
- `test_refactoring_generation`
- `test_save_and_retrieve_scan` (SQLite CRUD operations)

---

## 📊 Benchmark Test Samples

Pre-configured benchmark datasets are provided under `samples/`:
- **Python:** `sort_bubble_original.py`, `sort_bubble_type1.py`, `sort_bubble_type2.py`, `sort_bubble_type3.py`, `quicksort_control.py`
- **Java:** `BinarySearchOriginal.java`, `BinarySearchType1.java`, `BinarySearchType2.java`
- **C++:** `StackOriginal.cpp`, `StackType2.cpp`

You can run the one-click evaluation in the Web Dashboard **Benchmarks** tab to verify $100\%$ detection accuracy.

---

## 📡 REST API Reference

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/health` | Service status, metadata, team info, and algorithm descriptors |
| `POST` | `/api/detect/snippets` | Direct comparison of two code fragments with refactoring advice |
| `POST` | `/api/detect/files` | Multi-file batch scan with inverted indexing and DSU clustering |
| `POST` | `/api/detect/upload` | Multipart file upload and scan |
| `GET` | `/api/samples` | Curated benchmark sample suites and code fragments |
| `GET` | `/api/history` | Retrieve historical scans from SQLite database |
| `GET` | `/api/history/{id}` | Detailed scan report including all clone pairs and clusters |
| `DELETE`| `/api/history/{id}` | Delete a scan report by ID |
| `GET` | `/api/stats` | Database summary metrics (total scans and clone count) |
