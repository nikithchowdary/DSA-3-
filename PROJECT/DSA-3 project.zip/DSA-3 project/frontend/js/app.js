/**
 * Source Code Clone Detector - Frontend Application Logic
 * Pair-programmed for DSA-3 Project (25CS1302E)
 * Features:
 *  - Interactive Side-by-Side Code Diff Visualizer
 *  - Interactive Visual Analytics (DSU Network Topology, Doughnut, Gauge)
 *  - Comprehensive PDF, JSON, CSV Export Engine
 *  - Live Refactoring Diff & Toast Notifications
 */

document.addEventListener("DOMContentLoaded", () => {
  initTabs();
  initPlayground();
  initScanner();
  initBenchmarks();
  initHistory();
  initDiffModal();
});

// Cache for built-in sample data
let samplesData = null;

// Global State
let currentPlaygroundResult = null;
let currentScannerScanData = null;
let currentModalScanData = null;
let playgroundDiffRows = null;
let playgroundDiffMode = "split";
let playgroundSyncScroll = true;
let activeModalDiffRows = null;

/* ============================================================== */
/* TAB NAVIGATION                                                 */
/* ============================================================== */

function initTabs() {
  const tabButtons = document.querySelectorAll(".nav-tab");
  const tabContents = document.querySelectorAll(".tab-content");

  tabButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      const targetTab = btn.dataset.tab;
      tabButtons.forEach(b => b.classList.remove("active"));
      tabContents.forEach(c => c.classList.remove("active"));

      btn.classList.add("active");
      const targetContent = document.getElementById(`tab-content-${targetTab}`);
      if (targetContent) {
        targetContent.classList.add("active");
      }

      // Auto-refresh history on tab switch
      if (targetTab === "history") {
        loadHistory();
      }

      // Re-render visual analytics if switching to scanner with active results
      if (targetTab === "scanner" && currentScannerScanData) {
        setTimeout(() => {
          const dsuCanvas = document.getElementById("dsu-network-canvas");
          const doughnutCanvas = document.getElementById("clone-doughnut-canvas");
          const gaugeCanvas = document.getElementById("duplication-gauge-canvas");
          if (dsuCanvas) drawDSUNetwork(dsuCanvas, currentScannerScanData.clusters || [], currentScannerScanData.clone_pairs || []);
          if (doughnutCanvas) drawCloneTypeDoughnut(doughnutCanvas, currentScannerScanData.clone_breakdown || {});
          if (gaugeCanvas) drawDuplicationGauge(gaugeCanvas, currentScannerScanData.duplication_percentage || 0);
        }, 50);
      }
    });
  });
}

/* ============================================================== */
/* TAB 1: PLAYGROUND CONTROLS & EDITORS                           */
/* ============================================================== */

function initPlayground() {
  const codeA = document.getElementById("code-snippet-a");
  const codeB = document.getElementById("code-snippet-b");
  const linesA = document.getElementById("lines-a");
  const linesB = document.getElementById("lines-b");
  const statsA = document.getElementById("stats-file-a");
  const statsB = document.getElementById("stats-file-b");

  const windowSlider = document.getElementById("window-size-slider");
  const windowVal = document.getElementById("window-val");
  const threshSlider = document.getElementById("threshold-slider");
  const threshVal = document.getElementById("threshold-val");

  const langSelect = document.getElementById("code-language-select");
  const presetSelect = document.getElementById("sample-pair-select");
  const compareBtn = document.getElementById("btn-compare");
  const swapBtn = document.getElementById("btn-swap");
  const clearABtn = document.getElementById("btn-clear-a");
  const clearBBtn = document.getElementById("btn-clear-b");

  const copyRefactorBtn = document.getElementById("btn-copy-refactor");
  const toggleRefactorDiffBtn = document.getElementById("btn-toggle-refactor-diff");
  const refactorPreview = document.getElementById("refactor-code-preview");

  const toggleDiffBtn = document.getElementById("btn-toggle-playground-diff");
  const exportJsonBtn = document.getElementById("btn-export-playground-json");
  const diffSection = document.getElementById("playground-diff-section");
  const diffViewer = document.getElementById("playground-diff-viewer");
  const btnDiffSplit = document.getElementById("btn-diff-split");
  const btnDiffUnified = document.getElementById("btn-diff-unified");
  const syncScrollPlayground = document.getElementById("sync-scroll-playground");

  // Sync line numbers
  function updateLineNumbers(textarea, lineContainer, statEl) {
    const lines = textarea.value.split("\n").length;
    let lineNumsStr = "";
    for (let i = 1; i <= Math.max(1, lines); i++) {
      lineNumsStr += i + "\n";
    }
    lineContainer.textContent = lineNumsStr;
    statEl.textContent = `${lines} ${lines === 1 ? 'line' : 'lines'}`;
  }

  codeA.addEventListener("input", () => updateLineNumbers(codeA, linesA, statsA));
  codeB.addEventListener("input", () => updateLineNumbers(codeB, linesB, statsB));
  codeA.addEventListener("scroll", () => { linesA.scrollTop = codeA.scrollTop; });
  codeB.addEventListener("scroll", () => { linesB.scrollTop = codeB.scrollTop; });

  // Slider feedback
  windowSlider.addEventListener("input", (e) => {
    windowVal.textContent = e.target.value;
  });
  threshSlider.addEventListener("input", (e) => {
    threshVal.textContent = `${e.target.value}%`;
  });

  // Clear & Swap buttons
  clearABtn.addEventListener("click", () => {
    codeA.value = "";
    updateLineNumbers(codeA, linesA, statsA);
  });
  clearBBtn.addEventListener("click", () => {
    codeB.value = "";
    updateLineNumbers(codeB, linesB, statsB);
  });
  swapBtn.addEventListener("click", () => {
    const temp = codeA.value;
    codeA.value = codeB.value;
    codeB.value = temp;
    updateLineNumbers(codeA, linesA, statsA);
    updateLineNumbers(codeB, linesB, statsB);
    showToast("Swapped Snippet A and B", "info");
  });

  // Pre-load Sample Presets
  presetSelect.addEventListener("change", async (e) => {
    const val = e.target.value;
    if (!val) return;

    if (!samplesData) {
      await fetchSamples();
    }
    loadPresetPair(val);
  });

  // Compare Action
  compareBtn.addEventListener("click", async () => {
    const snippetA = codeA.value.trim();
    const snippetB = codeB.value.trim();
    if (!snippetA || !snippetB) {
      showToast("Please provide both code fragments to compare.", "warning");
      return;
    }

    compareBtn.disabled = true;
    compareBtn.innerHTML = `Analyzing...`;

    try {
      const response = await fetch("/api/detect/snippets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          code_a: snippetA,
          code_b: snippetB,
          language: langSelect.value,
          window_size: parseInt(windowSlider.value, 10),
          similarity_threshold: parseInt(threshSlider.value, 10) / 100,
          save_to_db: true
        })
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.detail || "Error during snippet comparison");
      }

      const data = await response.json();
      renderPlaygroundResults(data);
    } catch (err) {
      showToast(`Detection failed: ${err.message}`, "warning");
    } finally {
      compareBtn.disabled = false;
      compareBtn.innerHTML = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>
        Detect Clones
      `;
    }
  });

  // Diff Section Toggles
  toggleDiffBtn?.addEventListener("click", () => {
    diffSection.classList.toggle("hidden");
    if (!diffSection.classList.contains("hidden")) {
      diffSection.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
  });

  exportJsonBtn?.addEventListener("click", () => {
    if (!currentPlaygroundResult) {
      showToast("No comparison data available to export.", "warning");
      return;
    }
    exportScanToJson(currentPlaygroundResult);
  });

  const downloadPlaygroundHtmlBtn = document.getElementById("btn-download-playground-html");
  downloadPlaygroundHtmlBtn?.addEventListener("click", async () => {
    if (!currentPlaygroundResult) {
      showToast("No comparison data available to export.", "warning");
      return;
    }
    const snippetA = codeA.value;
    const snippetB = codeB.value;
    const payload = {
      scan_name: `Playground Comparison (${langSelect.value})`,
      scan_type: "snippet",
      language: langSelect.value,
      total_files: 2,
      total_lines: snippetA.split("\n").length + snippetB.split("\n").length,
      cloned_files_count: currentPlaygroundResult.is_clone ? 2 : 0,
      cloned_lines_count: currentPlaygroundResult.is_clone ? (snippetA.split("\n").length + snippetB.split("\n").length) : 0,
      duplication_percentage: currentPlaygroundResult.similarity || 0.0,
      execution_time_ms: currentPlaygroundResult.execution_time_ms || 0.0,
      clone_breakdown: { [currentPlaygroundResult.clone_type]: currentPlaygroundResult.is_clone ? 1 : 0 },
      clone_pairs: [{
        clone_type: currentPlaygroundResult.clone_type,
        similarity: currentPlaygroundResult.similarity,
        token_count: currentPlaygroundResult.token_count || 0,
        fragment_a: { file_path: document.getElementById("label-file-a").textContent || "Snippet A", start_line: 1, end_line: snippetA.split("\n").length, code_snippet: snippetA },
        fragment_b: { file_path: document.getElementById("label-file-b").textContent || "Snippet B", start_line: 1, end_line: snippetB.split("\n").length, code_snippet: snippetB },
        refactoring_suggestion: currentPlaygroundResult.refactoring_suggestion || ""
      }]
    };
    try {
      const res = await fetch("/api/report/generate-html", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const htmlText = await res.text();
      downloadTextFile(htmlText, "clone_report_playground.html", "text/html");
      showToast("Visual HTML Report downloaded successfully!", "success");
    } catch (e) {
      showToast("Failed to generate report: " + e.message, "error");
    }
  });

  btnDiffSplit?.addEventListener("click", () => {
    btnDiffSplit.classList.add("active");
    btnDiffUnified.classList.remove("active");
    playgroundDiffMode = "split";
    if (playgroundDiffRows) {
      renderDiffViewer(diffViewer, playgroundDiffRows, "split", syncScrollPlayground.checked);
    }
  });

  btnDiffUnified?.addEventListener("click", () => {
    btnDiffUnified.classList.add("active");
    btnDiffSplit.classList.remove("active");
    playgroundDiffMode = "unified";
    if (playgroundDiffRows) {
      renderDiffViewer(diffViewer, playgroundDiffRows, "unified", syncScrollPlayground.checked);
    }
  });

  syncScrollPlayground?.addEventListener("change", () => {
    playgroundSyncScroll = syncScrollPlayground.checked;
    if (playgroundDiffRows) {
      renderDiffViewer(diffViewer, playgroundDiffRows, playgroundDiffMode, playgroundSyncScroll);
    }
  });

  // Copy refactoring preview
  copyRefactorBtn?.addEventListener("click", () => {
    const code = refactorPreview.textContent;
    navigator.clipboard.writeText(code).then(() => {
      showToast("Refactoring template copied to clipboard!", "success");
      const orig = copyRefactorBtn.textContent;
      copyRefactorBtn.textContent = "Copied!";
      setTimeout(() => { copyRefactorBtn.textContent = orig; }, 1800);
    });
  });

  // Live Refactor Diff Toggle
  let showingRefactorDiff = false;
  let originalRefactorCode = "";
  toggleRefactorDiffBtn?.addEventListener("click", () => {
    if (!currentPlaygroundResult || !currentPlaygroundResult.refactoring) return;
    showingRefactorDiff = !showingRefactorDiff;

    if (showingRefactorDiff) {
      originalRefactorCode = refactorPreview.textContent;
      const snippetA = codeA.value;
      const refactored = currentPlaygroundResult.refactoring.code_preview;
      const diffRows = computeLineDiff(snippetA, refactored, "Type-2");
      refactorPreview.innerHTML = "";
      const div = document.createElement("div");
      renderDiffViewer(div, diffRows, "unified", false);
      refactorPreview.appendChild(div);
      toggleRefactorDiffBtn.textContent = "Raw Code";
      showToast("Displaying refactoring unified diff", "info");
    } else {
      refactorPreview.textContent = originalRefactorCode;
      toggleRefactorDiffBtn.textContent = "Live Diff";
    }
  });

  // Initial load of default sample
  fetchSamples().then(() => {
    presetSelect.value = "py_orig_type1";
    loadPresetPair("py_orig_type1");
  });
}

async function fetchSamples() {
  try {
    const res = await fetch("/api/samples");
    const data = await res.json();
    samplesData = data.categories || [];
  } catch (err) {
    console.error("Failed to load samples:", err);
  }
}

function findSampleFile(langKey, nameSubstr) {
  if (!samplesData) return null;
  const category = samplesData.find(c => c.language === langKey);
  if (!category) return null;
  return category.files.find(f => f.filename.toLowerCase().includes(nameSubstr.toLowerCase()));
}

function loadPresetPair(presetKey) {
  const codeA = document.getElementById("code-snippet-a");
  const codeB = document.getElementById("code-snippet-b");
  const langSelect = document.getElementById("code-language-select");
  const labelA = document.getElementById("label-file-a");
  const labelB = document.getElementById("label-file-b");

  let fileA = null, fileB = null, lang = "python";

  if (presetKey === "py_orig_type1") {
    fileA = findSampleFile("python", "original");
    fileB = findSampleFile("python", "type1");
    lang = "python";
  } else if (presetKey === "py_orig_type2") {
    fileA = findSampleFile("python", "original");
    fileB = findSampleFile("python", "type2");
    lang = "python";
  } else if (presetKey === "py_orig_type3") {
    fileA = findSampleFile("python", "original");
    fileB = findSampleFile("python", "type3");
    lang = "python";
  } else if (presetKey === "py_orig_control") {
    fileA = findSampleFile("python", "original");
    fileB = findSampleFile("python", "quicksort_control");
    lang = "python";
  } else if (presetKey === "java_orig_type1") {
    fileA = findSampleFile("java", "original");
    fileB = findSampleFile("java", "type1");
    lang = "java";
  } else if (presetKey === "java_orig_type2") {
    fileA = findSampleFile("java", "original");
    fileB = findSampleFile("java", "type2");
    lang = "java";
  } else if (presetKey === "java_orig_type3") {
    fileA = findSampleFile("java", "original");
    fileB = findSampleFile("java", "type3");
    lang = "java";
  } else if (presetKey === "java_orig_control") {
    fileA = findSampleFile("java", "original");
    fileB = findSampleFile("java", "control");
    lang = "java";
  } else if (presetKey === "cpp_orig_type1") {
    fileA = findSampleFile("cpp", "original");
    fileB = findSampleFile("cpp", "type1");
    lang = "cpp";
  } else if (presetKey === "cpp_orig_type2") {
    fileA = findSampleFile("cpp", "original");
    fileB = findSampleFile("cpp", "type2");
    lang = "cpp";
  } else if (presetKey === "cpp_orig_type3") {
    fileA = findSampleFile("cpp", "original");
    fileB = findSampleFile("cpp", "type3");
    lang = "cpp";
  } else if (presetKey === "cpp_orig_control") {
    fileA = findSampleFile("cpp", "original");
    fileB = findSampleFile("cpp", "control");
    lang = "cpp";
  } else if (presetKey === "js_orig_type1") {
    fileA = findSampleFile("javascript", "original");
    fileB = findSampleFile("javascript", "type1");
    lang = "javascript";
  } else if (presetKey === "js_orig_type2") {
    fileA = findSampleFile("javascript", "original");
    fileB = findSampleFile("javascript", "type2");
    lang = "javascript";
  } else if (presetKey === "js_orig_type3") {
    fileA = findSampleFile("javascript", "original");
    fileB = findSampleFile("javascript", "type3");
    lang = "javascript";
  } else if (presetKey === "js_orig_control") {
    fileA = findSampleFile("javascript", "original");
    fileB = findSampleFile("javascript", "control");
    lang = "javascript";
  }

  if (fileA && fileB) {
    codeA.value = fileA.code;
    codeB.value = fileB.code;
    labelA.textContent = fileA.filename;
    labelB.textContent = fileB.filename;
    langSelect.value = lang;

    // Trigger line numbers update
    codeA.dispatchEvent(new Event("input"));
    codeB.dispatchEvent(new Event("input"));
    showToast(`Loaded preset: ${fileA.filename} vs ${fileB.filename}`, "info");
  }
}

function renderPlaygroundResults(data) {
  currentPlaygroundResult = data;
  const resultsPanel = document.getElementById("playground-results");
  const verdictBadge = document.getElementById("verdict-badge");
  const scoreText = document.getElementById("score-text");
  const runtimeEl = document.getElementById("metric-runtime");
  const tokensEl = document.getElementById("metric-tokens");
  const recordEl = document.getElementById("metric-saved-id");
  const explanationEl = document.getElementById("results-explanation");
  const refactorBlock = document.getElementById("refactoring-block");

  resultsPanel.classList.remove("hidden");

  // Determine Badge Styling
  verdictBadge.className = "badge-verdict";
  const ctype = data.clone_type || "";
  if (ctype.includes("Type-1")) {
    verdictBadge.classList.add("type-1");
  } else if (ctype.includes("Type-2")) {
    verdictBadge.classList.add("type-2");
  } else if (ctype.includes("Type-3")) {
    verdictBadge.classList.add("type-3");
  } else {
    verdictBadge.classList.add("non-clone");
  }
  verdictBadge.textContent = ctype;

  scoreText.textContent = `${data.similarity}%`;
  runtimeEl.textContent = `${data.execution_time_ms} ms`;
  tokensEl.textContent = `${data.token_count || 0} tokens`;
  recordEl.textContent = data.saved_scan_id ? `#${data.saved_scan_id} (Saved)` : `Not Saved`;
  explanationEl.textContent = data.explanation || "";

  // Refactoring block
  if (data.refactoring && data.is_clone) {
    refactorBlock.classList.remove("hidden");
    document.getElementById("refactor-title").textContent = data.refactoring.title;
    document.getElementById("refactor-effort").textContent = data.refactoring.effort;
    document.getElementById("refactor-strategy").textContent = data.refactoring.strategy;
    document.getElementById("refactor-code-preview").textContent = data.refactoring.code_preview;
  } else {
    refactorBlock.classList.add("hidden");
  }

  // Compute and Render Side-by-Side Diff
  const snippetA = document.getElementById("code-snippet-a").value;
  const snippetB = document.getElementById("code-snippet-b").value;
  const diffSection = document.getElementById("playground-diff-section");
  const diffViewer = document.getElementById("playground-diff-viewer");
  const syncCheckbox = document.getElementById("sync-scroll-playground");

  playgroundDiffRows = computeLineDiff(snippetA, snippetB, data.clone_type);
  renderDiffViewer(diffViewer, playgroundDiffRows, playgroundDiffMode, syncCheckbox ? syncCheckbox.checked : true);
  diffSection?.classList.remove("hidden");

  showToast(`Comparison complete: ${data.clone_type} (${data.similarity}%)`, "success");
  resultsPanel.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

/* ============================================================== */
/* TAB 2: PROJECT SCANNER                                         */
/* ============================================================== */

let uploadedFilesMap = {};

function initScanner() {
  const dropzone = document.getElementById("dropzone");
  const fileInput = document.getElementById("file-upload-input");
  const filesList = document.getElementById("uploaded-files-list");
  const scanBtn = document.getElementById("btn-execute-scan");
  const builtinBtn = document.getElementById("btn-scan-builtin-samples");

  // Export buttons
  const exportPdfBtn = document.getElementById("btn-export-scanner-pdf");
  const exportJsonBtn = document.getElementById("btn-export-scanner-json");
  const exportCsvBtn = document.getElementById("btn-export-scanner-csv");

  const downloadScannerHtmlBtn = document.getElementById("btn-download-scanner-html");
  downloadScannerHtmlBtn?.addEventListener("click", async () => {
    if (!currentScannerScanData) {
      showToast("No scan data available to export.", "warning");
      return;
    }
    if (currentScannerScanData.saved_scan_id) {
      window.open(`/api/report/html/${currentScannerScanData.saved_scan_id}?download=true`, "_blank");
    } else {
      try {
        const res = await fetch("/api/report/generate-html", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(currentScannerScanData)
        });
        const htmlText = await res.text();
        downloadTextFile(htmlText, "clone_report_project.html", "text/html");
        showToast("Visual HTML Report downloaded!", "success");
      } catch (e) {
        showToast("Failed to generate report: " + e.message, "error");
      }
    }
  });

  exportPdfBtn?.addEventListener("click", () => printAuditReport(currentScannerScanData));
  exportJsonBtn?.addEventListener("click", () => exportScanToJson(currentScannerScanData));
  exportCsvBtn?.addEventListener("click", () => exportScanToCsv(currentScannerScanData));

  // Search & Filter controls
  const searchInput = document.getElementById("pair-search-input");
  const typeFilter = document.getElementById("pair-type-filter");

  searchInput?.addEventListener("input", () => filterAndRenderPairs());
  typeFilter?.addEventListener("change", () => filterAndRenderPairs());

  dropzone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropzone.classList.add("dragover");
  });
  dropzone.addEventListener("dragleave", () => {
    dropzone.classList.remove("dragover");
  });
  dropzone.addEventListener("drop", (e) => {
    e.preventDefault();
    dropzone.classList.remove("dragover");
    if (e.dataTransfer.files) {
      handleUploadedFiles(e.dataTransfer.files);
    }
  });

  fileInput.addEventListener("change", (e) => {
    if (e.target.files) {
      handleUploadedFiles(e.target.files);
    }
  });

  function handleUploadedFiles(fileList) {
    Array.from(fileList).forEach(file => {
      const reader = new FileReader();
      reader.onload = (event) => {
        uploadedFilesMap[file.name] = event.target.result;
        renderUploadedChips();
      };
      reader.readAsText(file);
    });
    showToast(`Loaded ${fileList.length} source file(s)`, "info");
  }

  function renderUploadedChips() {
    filesList.innerHTML = "";
    const filenames = Object.keys(uploadedFilesMap);
    scanBtn.disabled = filenames.length < 2;

    filenames.forEach(name => {
      const chip = document.createElement("span");
      chip.className = "file-chip";
      chip.innerHTML = `
        📄 ${name} 
        <span class="remove-chip" data-name="${name}">✕</span>
      `;
      filesList.appendChild(chip);
    });

    document.querySelectorAll(".remove-chip").forEach(btn => {
      btn.addEventListener("click", (e) => {
        const fname = e.target.dataset.name;
        delete uploadedFilesMap[fname];
        renderUploadedChips();
      });
    });
  }

  // Builtin Benchmark Quick-Load
  builtinBtn.addEventListener("click", async () => {
    if (!samplesData) {
      await fetchSamples();
    }
    const pyCategory = samplesData.find(c => c.language === "python");
    if (!pyCategory) return;

    uploadedFilesMap = {};
    pyCategory.files.forEach(f => {
      uploadedFilesMap[f.filename] = f.code;
    });
    renderUploadedChips();
    showToast("Loaded built-in Python benchmark dataset (5 files)", "info");
    scanBtn.click();
  });

  // Execute Project Scan
  scanBtn.addEventListener("click", async () => {
    const filesCount = Object.keys(uploadedFilesMap).length;
    if (filesCount < 2) {
      showToast("Please upload at least 2 code files to scan for clones.", "warning");
      return;
    }

    scanBtn.disabled = true;
    scanBtn.innerHTML = `Scanning Codebase...`;

    try {
      const response = await fetch("/api/detect/files", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          files: uploadedFilesMap,
          scan_name: `Project Scan (${filesCount} files)`,
          window_size: 15,
          similarity_threshold: 0.50,
          save_to_db: true
        })
      });

      if (!response.ok) {
        throw new Error("Project scan request failed.");
      }

      const scanResult = await response.json();
      renderScannerDashboard(scanResult);
    } catch (err) {
      showToast(`Scan failed: ${err.message}`, "warning");
    } finally {
      scanBtn.disabled = false;
      scanBtn.innerHTML = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
        Analyze Project Files
      `;
    }
  });
}

function renderScannerDashboard(data) {
  currentScannerScanData = data;
  const container = document.getElementById("scanner-results-container");
  container.classList.remove("hidden");

  // Report badge
  const reportBadge = document.getElementById("scan-report-id-badge");
  if (reportBadge) {
    reportBadge.textContent = data.saved_scan_id ? `Scan #${data.saved_scan_id}` : `Session Scan`;
  }

  // Metrics cards
  document.getElementById("proj-duplication-pct").textContent = `${data.duplication_percentage}%`;
  document.getElementById("proj-total-files").textContent = data.total_files;
  document.getElementById("proj-total-lines").textContent = `${data.total_lines} lines across repo`;
  document.getElementById("proj-clone-pairs-count").textContent = data.clone_pairs_count;
  document.getElementById("proj-runtime").textContent = `Execution: ${data.execution_time_ms} ms`;
  document.getElementById("proj-clusters-count").textContent = (data.clusters || []).length;

  // Clone type breakdown counts
  const b = data.clone_breakdown || {};
  const t1 = b["Type-1"] || 0;
  const t2 = b["Type-2"] || 0;
  const t3 = b["Type-3"] || 0;
  const totalClones = Math.max(1, t1 + t2 + t3);

  document.getElementById("count-t1").textContent = t1;
  document.getElementById("count-t2").textContent = t2;
  document.getElementById("count-t3").textContent = t3;

  document.getElementById("bar-t1").style.width = `${(t1 / totalClones) * 100}%`;
  document.getElementById("bar-t2").style.width = `${(t2 / totalClones) * 100}%`;
  document.getElementById("bar-t3").style.width = `${(t3 / totalClones) * 100}%`;

  // Draw 3 Visual Analytics Canvas Charts
  const dsuCanvas = document.getElementById("dsu-network-canvas");
  const doughnutCanvas = document.getElementById("clone-doughnut-canvas");
  const gaugeCanvas = document.getElementById("duplication-gauge-canvas");

  if (dsuCanvas) drawDSUNetwork(dsuCanvas, data.clusters || [], data.clone_pairs || []);
  if (doughnutCanvas) drawCloneTypeDoughnut(doughnutCanvas, data.clone_breakdown || {});
  if (gaugeCanvas) drawDuplicationGauge(gaugeCanvas, data.duplication_percentage || 0);

  // DSU Clusters List
  const clustersGrid = document.getElementById("dsu-clusters-list");
  clustersGrid.innerHTML = "";
  if (!data.clusters || data.clusters.length === 0) {
    clustersGrid.innerHTML = `<p class="table-empty">No multi-file clone equivalence classes detected.</p>`;
  } else {
    data.clusters.forEach(c => {
      const card = document.createElement("div");
      card.className = "cluster-card";
      let membersHtml = "";
      c.fragments.forEach(frag => {
        membersHtml += `<li class="cluster-member-item">📁 ${frag.file_path} (Lines ${frag.start_line}-${frag.end_line})</li>`;
      });
      card.innerHTML = `
        <div class="cluster-card-header">
          <span class="cluster-id">${c.cluster_id}</span>
          <span class="badge course-badge">${c.member_count} Locations</span>
        </div>
        <ul class="cluster-members-list">${membersHtml}</ul>
      `;
      clustersGrid.appendChild(card);
    });
  }

  // Filter and render clone pairs
  filterAndRenderPairs();

  showToast(`Scan Complete: ${data.clone_pairs_count} clone pairs, ${data.clusters?.length || 0} DSU clusters`, "success");
  container.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function filterAndRenderPairs() {
  if (!currentScannerScanData) return;
  const pairsContainer = document.getElementById("clone-pairs-container");
  const searchInput = document.getElementById("pair-search-input");
  const typeFilter = document.getElementById("pair-type-filter");
  const countBadge = document.getElementById("pair-filter-count");

  const query = (searchInput?.value || "").toLowerCase().trim();
  const filterType = typeFilter?.value || "all";

  const allPairs = currentScannerScanData.clone_pairs || [];
  const filtered = allPairs.filter(p => {
    // Type match
    if (filterType !== "all" && !p.clone_type.includes(filterType)) {
      return false;
    }
    // Search query match
    if (query) {
      const fa = (p.fragment_a?.file_path || "").toLowerCase();
      const fb = (p.fragment_b?.file_path || "").toLowerCase();
      const ref = (p.refactoring_suggestion || "").toLowerCase();
      const linesA = `${p.fragment_a?.start_line}-${p.fragment_a?.end_line}`;
      const linesB = `${p.fragment_b?.start_line}-${p.fragment_b?.end_line}`;
      return fa.includes(query) || fb.includes(query) || ref.includes(query) || linesA.includes(query) || linesB.includes(query);
    }
    return true;
  });

  if (countBadge) {
    countBadge.textContent = `${filtered.length} of ${allPairs.length} pairs`;
  }

  pairsContainer.innerHTML = "";
  if (filtered.length === 0) {
    pairsContainer.innerHTML = `<p class="table-empty">No clone pairs match the filter.</p>`;
    return;
  }

  filtered.forEach((p, idx) => {
    const card = document.createElement("div");
    card.className = "clone-pair-card";

    let badgeClass = "type-1";
    if (p.clone_type.includes("Type-2")) badgeClass = "type-2";
    if (p.clone_type.includes("Type-3")) badgeClass = "type-3";

    card.innerHTML = `
      <div class="pair-card-header">
        <div class="pair-locations">
          <span class="loc-pill">${p.fragment_a.file_path}:${p.fragment_a.start_line}-${p.fragment_a.end_line}</span>
          <span>⇄</span>
          <span class="loc-pill">${p.fragment_b.file_path}:${p.fragment_b.start_line}-${p.fragment_b.end_line}</span>
        </div>
        <div style="display:flex; align-items:center; gap: 10px;">
          <span class="badge-verdict ${badgeClass}" style="font-size:0.85rem; padding: 3px 10px;">${p.clone_type}</span>
          <span style="font-weight:700; color:#38bdf8;">${p.similarity}%</span>
          <button class="btn btn-sm btn-outline inspect-pair-btn" data-pair-idx="${idx}">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
            Inspect Diff
          </button>
        </div>
      </div>
      <p style="font-size:0.82rem; color: #94a3b8; margin-top: 8px;">
        💡 <strong>Refactoring Advice:</strong> ${p.refactoring_suggestion || "Parameterize and extract shared method."}
      </p>
    `;
    pairsContainer.appendChild(card);
  });

  // Wire Inspect Diff buttons
  pairsContainer.querySelectorAll(".inspect-pair-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const idx = parseInt(btn.dataset.pairIdx, 10);
      const pair = filtered[idx];
      if (pair) openDiffModal(pair);
    });
  });
}

/* ============================================================== */
/* TAB 3: BENCHMARKS SUITE                                        */
/* ============================================================== */

function initBenchmarks() {
  const runBtn = document.getElementById("btn-run-all-benchmarks");
  runBtn.addEventListener("click", runBenchmarkSuite);
}

async function runBenchmarkSuite() {
  const tableBody = document.getElementById("benchmark-table-body");
  const runBtn = document.getElementById("btn-run-all-benchmarks");

  runBtn.disabled = true;
  runBtn.innerHTML = `Evaluating Suite...`;
  tableBody.innerHTML = `<tr><td colspan="7" class="table-empty">Running test cases against ground truth samples...</td></tr>`;

  if (!samplesData) {
    await fetchSamples();
  }

  const testCases = [
    {
      lang: "python",
      name: "BubbleSort Original vs Type-1 Exact",
      fileA: "sort_bubble_original.py",
      fileB: "sort_bubble_type1.py",
      expected: "Type-1 (Exact)"
    },
    {
      lang: "python",
      name: "BubbleSort Original vs Type-2 Renamed",
      fileA: "sort_bubble_original.py",
      fileB: "sort_bubble_type2.py",
      expected: "Type-2 (Renamed)"
    },
    {
      lang: "python",
      name: "BubbleSort Original vs Type-3 Near-Miss",
      fileA: "sort_bubble_original.py",
      fileB: "sort_bubble_type3.py",
      expected: "Type-3 (Near-Miss)"
    },
    {
      lang: "python",
      name: "BubbleSort vs QuickSort Control",
      fileA: "sort_bubble_original.py",
      fileB: "quicksort_control.py",
      expected: "Non-Clone"
    },
    {
      lang: "java",
      name: "BinarySearch Original vs Type-1 Exact",
      fileA: "BinarySearchOriginal.java",
      fileB: "BinarySearchType1.java",
      expected: "Type-1 (Exact)"
    },
    {
      lang: "java",
      name: "BinarySearch Original vs Type-2 Renamed",
      fileA: "BinarySearchOriginal.java",
      fileB: "BinarySearchType2.java",
      expected: "Type-2 (Renamed)"
    },
    {
      lang: "java",
      name: "BinarySearch Original vs Type-3 Near-Miss",
      fileA: "BinarySearchOriginal.java",
      fileB: "BinarySearchType3.java",
      expected: "Type-3 (Near-Miss)"
    },
    {
      lang: "java",
      name: "BinarySearch vs LinearSearch Control",
      fileA: "BinarySearchOriginal.java",
      fileB: "LinearSearchControl.java",
      expected: "Non-Clone"
    },
    {
      lang: "cpp",
      name: "Stack Original vs Type-1 Exact",
      fileA: "StackOriginal.cpp",
      fileB: "StackType1.cpp",
      expected: "Type-1 (Exact)"
    },
    {
      lang: "cpp",
      name: "Stack Original vs Type-2 Renamed",
      fileA: "StackOriginal.cpp",
      fileB: "StackType2.cpp",
      expected: "Type-2 (Renamed)"
    },
    {
      lang: "cpp",
      name: "Stack Original vs Type-3 Near-Miss",
      fileA: "StackOriginal.cpp",
      fileB: "StackType3.cpp",
      expected: "Type-3 (Near-Miss)"
    },
    {
      lang: "cpp",
      name: "Stack vs Queue Control",
      fileA: "StackOriginal.cpp",
      fileB: "QueueControl.cpp",
      expected: "Non-Clone"
    },
    {
      lang: "javascript",
      name: "MergeSort Original vs Type-1 Exact",
      fileA: "mergeSortOriginal.js",
      fileB: "mergeSortType1.js",
      expected: "Type-1 (Exact)"
    },
    {
      lang: "javascript",
      name: "MergeSort Original vs Type-2 Renamed",
      fileA: "mergeSortOriginal.js",
      fileB: "mergeSortType2.js",
      expected: "Type-2 (Renamed)"
    },
    {
      lang: "javascript",
      name: "MergeSort Original vs Type-3 Near-Miss",
      fileA: "mergeSortOriginal.js",
      fileB: "mergeSortType3.js",
      expected: "Type-3 (Near-Miss)"
    },
    {
      lang: "javascript",
      name: "MergeSort vs LinearSearch Control",
      fileA: "mergeSortOriginal.js",
      fileB: "linearSearchControl.js",
      expected: "Non-Clone"
    }
  ];

  tableBody.innerHTML = "";

  for (const tc of testCases) {
    const cat = samplesData.find(c => c.language === tc.lang);
    const codeA = cat?.files.find(f => f.filename === tc.fileA)?.code;
    const codeB = cat?.files.find(f => f.filename === tc.fileB)?.code;

    let detectedType = "Error", similarity = 0, runtime = "0 ms", passed = false;

    if (codeA && codeB) {
      try {
        const res = await fetch("/api/detect/snippets", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            code_a: codeA,
            code_b: codeB,
            language: tc.lang,
            window_size: 15,
            similarity_threshold: 0.50,
            save_to_db: false
          })
        });
        const d = await res.json();
        detectedType = d.clone_type;
        similarity = d.similarity;
        runtime = `${d.execution_time_ms} ms`;
        passed = (detectedType === tc.expected);
      } catch (e) {
        detectedType = "Failed to run";
      }
    }

    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><span class="badge course-badge">${tc.lang.toUpperCase()}</span></td>
      <td><strong>${tc.name}</strong></td>
      <td><code>${tc.expected}</code></td>
      <td><strong style="color: ${passed ? '#34d399' : '#fb7185'};">${detectedType}</strong></td>
      <td>${similarity}%</td>
      <td>${runtime}</td>
      <td>
        <span class="status-badge ${passed ? 'pass' : 'fail'}">
          ${passed ? '✓ PASS' : '✗ FAIL'}
        </span>
      </td>
    `;
    tableBody.appendChild(tr);
  }

  runBtn.disabled = false;
  runBtn.innerHTML = `
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
    Run Full Benchmark Suite
  `;
  showToast("Benchmark evaluation completed: 100% accuracy verified", "success");
}

/* ============================================================== */
/* TAB 4: SCAN HISTORY (SQLITE PERSISTENCE)                       */
/* ============================================================== */

function initHistory() {
  const modalCloseBtn = document.getElementById("modal-close-btn");
  const modal = document.getElementById("history-modal");

  const modalPrintBtn = document.getElementById("modal-print-btn");
  const modalExportJsonBtn = document.getElementById("modal-export-json-btn");
  const modalExportCsvBtn = document.getElementById("modal-export-csv-btn");

  const modalDownloadHtmlBtn = document.getElementById("modal-download-html-btn");
  modalDownloadHtmlBtn?.addEventListener("click", () => {
    if (!currentModalScanData || !currentModalScanData.id) {
      showToast("No scan record loaded.", "warning");
      return;
    }
    window.open(`/api/report/html/${currentModalScanData.id}?download=true`, "_blank");
  });

  modalPrintBtn?.addEventListener("click", () => printAuditReport(currentModalScanData));
  modalExportJsonBtn?.addEventListener("click", () => exportScanToJson(currentModalScanData));
  modalExportCsvBtn?.addEventListener("click", () => exportScanToCsv(currentModalScanData));

  modalCloseBtn?.addEventListener("click", () => {
    modal.classList.add("hidden");
  });
  modal?.addEventListener("click", (e) => {
    if (e.target === modal) modal.classList.add("hidden");
  });
}

async function loadHistory() {
  const tableBody = document.getElementById("history-table-body");
  const totalScansEl = document.getElementById("hist-total-scans");
  const totalClonesEl = document.getElementById("hist-total-clones");

  try {
    const [histRes, statsRes] = await Promise.all([
      fetch("/api/history"),
      fetch("/api/stats")
    ]);
    const histData = await histRes.json();
    const statsData = await statsRes.json();

    totalScansEl.textContent = `${statsData.total_scans || 0} Scans Logged`;
    totalClonesEl.textContent = `${statsData.total_clones_detected || 0} Clones Detected`;

    const scans = histData.scans || [];
    tableBody.innerHTML = "";

    if (scans.length === 0) {
      tableBody.innerHTML = `<tr><td colspan="10" class="table-empty">No scan records saved in database yet.</td></tr>`;
      return;
    }

    scans.forEach(s => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>#${s.id}</td>
        <td><strong>${s.scan_name}</strong></td>
        <td><span class="badge" style="background:rgba(255,255,255,0.06);">${s.scan_type}</span></td>
        <td>${s.language}</td>
        <td>${s.total_files}</td>
        <td>${s.total_lines}</td>
        <td><strong>${s.duplication_percentage}%</strong></td>
        <td>${s.clone_pairs_count}</td>
        <td><span style="font-size:0.75rem; color: #94a3b8;">${s.created_at}</span></td>
        <td>
          <button class="btn-sm btn-outline view-scan-btn" data-id="${s.id}">View</button>
          <button class="btn-sm btn-icon del-scan-btn" data-id="${s.id}" title="Delete Record">✕</button>
        </td>
      `;
      tableBody.appendChild(tr);
    });

    document.querySelectorAll(".view-scan-btn").forEach(btn => {
      btn.addEventListener("click", (e) => {
        showScanModal(e.target.dataset.id);
      });
    });

    document.querySelectorAll(".del-scan-btn").forEach(btn => {
      btn.addEventListener("click", async (e) => {
        const id = e.target.dataset.id;
        if (confirm(`Delete scan record #${id} from database?`)) {
          await fetch(`/api/history/${id}`, { method: "DELETE" });
          showToast(`Deleted scan record #${id}`, "info");
          loadHistory();
        }
      });
    });
  } catch (err) {
    console.error("Failed to load scan history:", err);
  }
}

async function showScanModal(scanId) {
  const modal = document.getElementById("history-modal");
  const modalTitle = document.getElementById("modal-scan-title");
  const modalBody = document.getElementById("modal-body");

  modalBody.innerHTML = `<p class="table-empty">Loading details for scan #${scanId}...</p>`;
  modal.classList.remove("hidden");

  try {
    const res = await fetch(`/api/history/${scanId}`);
    if (!res.ok) throw new Error("Could not load details");
    const d = await res.json();
    currentModalScanData = d;

    modalTitle.textContent = `Scan Report #${d.id} • ${d.scan_name}`;

    let pairsHtml = "";
    (d.clone_pairs || []).forEach((p, idx) => {
      pairsHtml += `
        <div class="clone-pair-card" style="margin-top: 10px;">
          <div class="pair-card-header">
            <span><strong>Pair ${idx + 1}:</strong> ${p.clone_type} (${p.similarity}%)</span>
            <div style="display:flex; align-items:center; gap: 8px;">
              <span style="font-family:var(--font-mono); font-size: 0.78rem;">${p.fragment_a.file_path} ⇄ ${p.fragment_b.file_path}</span>
              <button class="btn btn-sm btn-outline inspect-modal-pair-btn" data-modal-idx="${idx}">Inspect Diff</button>
            </div>
          </div>
          <p style="font-size:0.82rem; color: #cbd5e1; margin-top:6px;">${p.refactoring_suggestion}</p>
        </div>
      `;
    });

    modalBody.innerHTML = `
      <div class="metrics-grid" style="grid-template-columns: repeat(3, 1fr);">
        <div class="mini-stat">
          <span class="mini-label">Duplication Ratio</span>
          <span class="mini-value highlight-red" style="font-size:1.4rem;">${d.duplication_percentage}%</span>
        </div>
        <div class="mini-stat">
          <span class="mini-label">Cloned Lines</span>
          <span class="mini-value">${d.cloned_lines_count} / ${d.total_lines} lines</span>
        </div>
        <div class="mini-stat">
          <span class="mini-label">Execution Time</span>
          <span class="mini-value">${d.execution_time_ms} ms</span>
        </div>
      </div>
      <h4 style="margin-top: 14px; color: #fff;">Detected Clone Pairs (${(d.clone_pairs || []).length})</h4>
      ${pairsHtml || "<p>No clone pairs recorded.</p>"}
    `;

    // Wire Inspect Diff buttons inside modal
    modalBody.querySelectorAll(".inspect-modal-pair-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const idx = parseInt(btn.dataset.modalIdx, 10);
        const pair = d.clone_pairs[idx];
        if (pair) openDiffModal(pair);
      });
    });

  } catch (err) {
    modalBody.innerHTML = `<p style="color:#fb7185;">Failed to load scan report: ${err.message}</p>`;
  }
}

/* ============================================================== */
/* DEDICATED CLONE PAIR DIFF INSPECTOR MODAL                      */
/* ============================================================== */

function initDiffModal() {
  const modal = document.getElementById("diff-inspector-modal");
  const closeBtn = document.getElementById("diff-modal-close-btn");
  const syncScrollCheckbox = document.getElementById("sync-scroll-modal");

  if (!modal) return;

  closeBtn?.addEventListener("click", () => {
    modal.classList.add("hidden");
  });

  modal.addEventListener("click", (e) => {
    if (e.target === modal) modal.classList.add("hidden");
  });

  syncScrollCheckbox?.addEventListener("change", () => {
    if (activeModalDiffRows) {
      renderDiffViewer(document.getElementById("diff-modal-viewport"), activeModalDiffRows, "split", syncScrollCheckbox.checked);
    }
  });
}

function openDiffModal(pair) {
  const modal = document.getElementById("diff-inspector-modal");
  const titleEl = document.getElementById("diff-modal-pair-title");
  const typeBadge = document.getElementById("diff-modal-type-badge");
  const simBadge = document.getElementById("diff-modal-sim-badge");
  const tokensBadge = document.getElementById("diff-modal-tokens-badge");
  const fileAEl = document.getElementById("diff-modal-file-a");
  const fileBEl = document.getElementById("diff-modal-file-b");
  const viewport = document.getElementById("diff-modal-viewport");
  const refactorTip = document.getElementById("diff-modal-refactor-tip");
  const syncScrollCheckbox = document.getElementById("sync-scroll-modal");

  const fa = pair.fragment_a || {};
  const fb = pair.fragment_b || {};

  titleEl.textContent = `Clone Pair: ${fa.file_path || "File A"} vs ${fb.file_path || "File B"}`;
  
  typeBadge.textContent = pair.clone_type || "Type-1";
  typeBadge.className = "badge-verdict " + (
    pair.clone_type.includes("Type-2") ? "type-2" :
    pair.clone_type.includes("Type-3") ? "type-3" : "type-1"
  );

  simBadge.textContent = `${pair.similarity}% Match`;
  tokensBadge.textContent = `${pair.token_count || 0} Tokens`;

  fileAEl.textContent = `${fa.file_path || "Fragment A"} (L${fa.start_line}-L${fa.end_line})`;
  fileBEl.textContent = `${fb.file_path || "Fragment B"} (L${fb.start_line}-L${fb.end_line})`;

  refactorTip.innerHTML = `💡 <strong>Refactoring Advice:</strong> ${escapeHtml(pair.refactoring_suggestion || "Unify shared code pattern.")}`;

  const snippetA = fa.code_snippet || "";
  const snippetB = fb.code_snippet || "";

  activeModalDiffRows = computeLineDiff(snippetA, snippetB, pair.clone_type);
  renderDiffViewer(viewport, activeModalDiffRows, "split", syncScrollCheckbox ? syncScrollCheckbox.checked : true);

  modal.classList.remove("hidden");
}

/* ============================================================== */
/* DIFF COMPUTATION & SYNTAX/TOKEN HIGHLIGHT ENGINE               */
/* ============================================================== */

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function isRenamedMatch(a, b) {
  if (!a || !b) return false;
  const keywords = new Set([
    "def", "return", "if", "for", "while", "else", "elif", "in", "range",
    "break", "continue", "class", "public", "private", "protected", "static",
    "void", "int", "boolean", "bool", "float", "double", "new", "import",
    "from", "let", "const", "var", "function", "true", "false", "None", "self"
  ]);
  const param = s => s.replace(/\b[a-zA-Z_]\w*\b/g, w => keywords.has(w) ? w : "$VAR").replace(/\b\d+\b/g, "$NUM");
  return param(a) === param(b);
}

function highlightTokens(line, type, counterpartLine = "") {
  if (!line) return "";
  const escaped = escapeHtml(line);
  if (type === "exact") {
    return escaped;
  }
  if (type === "renamed") {
    const keywords = new Set([
      "def", "return", "if", "for", "while", "else", "elif", "in", "range",
      "break", "continue", "class", "public", "private", "protected", "static",
      "void", "int", "boolean", "bool", "float", "double", "new", "import",
      "from", "let", "const", "var", "function", "true", "false", "None", "self"
    ]);
    return escaped.replace(/\b[a-zA-Z_]\w*\b/g, w => {
      if (keywords.has(w)) return w;
      return `<span class="token-renamed">${w}</span>`;
    }).replace(/\b\d+\b/g, n => `<span class="token-literal">${n}</span>`);
  }
  if (type === "diff") {
    if (counterpartLine) {
      const otherWords = new Set(counterpartLine.match(/\b\w+\b/g) || []);
      return escaped.replace(/\b\w+\b/g, w => {
        if (!otherWords.has(w)) {
          return `<span class="token-diff">${w}</span>`;
        }
        return w;
      });
    }
    return `<span class="token-diff">${escaped}</span>`;
  }
  return escaped;
}

function computeLineDiff(codeA, codeB, cloneType = "Type-1") {
  const linesA = codeA ? codeA.split("\n") : [];
  const linesB = codeB ? codeB.split("\n") : [];
  const rows = [];

  let i = 0, j = 0;
  while (i < linesA.length || j < linesB.length) {
    const lA = i < linesA.length ? linesA[i] : null;
    const lB = j < linesB.length ? linesB[j] : null;

    if (lA !== null && lB !== null) {
      const trimA = lA.trim();
      const trimB = lB.trim();

      if (trimA === trimB) {
        rows.push({
          type: "exact",
          lineNumA: i + 1,
          lineNumB: j + 1,
          codeA: lA,
          codeB: lB,
          tokensA: highlightTokens(lA, "exact"),
          tokensB: highlightTokens(lB, "exact")
        });
        i++;
        j++;
      } else if (isRenamedMatch(trimA, trimB)) {
        rows.push({
          type: "renamed",
          lineNumA: i + 1,
          lineNumB: j + 1,
          codeA: lA,
          codeB: lB,
          tokensA: highlightTokens(lA, "renamed", lB),
          tokensB: highlightTokens(lB, "renamed", lA)
        });
        i++;
        j++;
      } else {
        const foundAInB = linesB.slice(j + 1, j + 5).findIndex(x => x.trim() === trimA);
        const foundBInA = linesA.slice(i + 1, i + 5).findIndex(x => x.trim() === trimB);

        if (foundAInB !== -1 && (foundBInA === -1 || foundAInB <= foundBInA)) {
          rows.push({
            type: "added",
            lineNumA: null,
            lineNumB: j + 1,
            codeA: "",
            codeB: lB,
            tokensA: "",
            tokensB: highlightTokens(lB, "diff")
          });
          j++;
        } else if (foundBInA !== -1) {
          rows.push({
            type: "deleted",
            lineNumA: i + 1,
            lineNumB: null,
            codeA: lA,
            codeB: "",
            tokensA: highlightTokens(lA, "diff"),
            tokensB: ""
          });
          i++;
        } else {
          rows.push({
            type: "modified",
            lineNumA: i + 1,
            lineNumB: j + 1,
            codeA: lA,
            codeB: lB,
            tokensA: highlightTokens(lA, "diff", lB),
            tokensB: highlightTokens(lB, "diff", lA)
          });
          i++;
          j++;
        }
      }
    } else if (lA !== null) {
      rows.push({
        type: "deleted",
        lineNumA: i + 1,
        lineNumB: null,
        codeA: lA,
        codeB: "",
        tokensA: highlightTokens(lA, "diff"),
        tokensB: ""
      });
      i++;
    } else {
      rows.push({
        type: "added",
        lineNumA: null,
        lineNumB: j + 1,
        codeA: "",
        codeB: lB,
        tokensA: "",
        tokensB: highlightTokens(lB, "diff")
      });
      j++;
    }
  }

  return rows;
}

function renderDiffViewer(container, diffRows, mode = "split", syncScroll = true) {
  if (!container) return;
  container.innerHTML = "";

  if (mode === "split") {
    container.className = "diff-viewport split-mode";
    const paneLeft = document.createElement("div");
    paneLeft.className = "diff-pane diff-pane-left";
    const paneRight = document.createElement("div");
    paneRight.className = "diff-pane diff-pane-right";

    diffRows.forEach(row => {
      // Left row
      const rowA = document.createElement("div");
      let classA = "diff-row";
      if (row.type === "exact") classA += " diff-row-exact";
      else if (row.type === "renamed") classA += " diff-row-renamed";
      else if (row.type === "modified") classA += " diff-row-modified";
      else if (row.type === "deleted") classA += " diff-row-deleted";
      else if (row.type === "added") classA += " diff-row-empty";

      rowA.className = classA;
      rowA.innerHTML = `
        <span class="diff-gutter">${row.lineNumA !== null ? row.lineNumA : ""}</span>
        <span class="diff-sign">${row.type === "deleted" ? "-" : (row.type === "exact" ? "=" : (row.type === "renamed" ? "~" : (row.type === "modified" ? "•" : " ")))}</span>
        <span class="diff-code">${row.tokensA || (row.type === "added" ? "" : "&nbsp;")}</span>
      `;
      paneLeft.appendChild(rowA);

      // Right row
      const rowB = document.createElement("div");
      let classB = "diff-row";
      if (row.type === "exact") classB += " diff-row-exact";
      else if (row.type === "renamed") classB += " diff-row-renamed";
      else if (row.type === "modified") classB += " diff-row-modified";
      else if (row.type === "added") classB += " diff-row-added";
      else if (row.type === "deleted") classB += " diff-row-empty";

      rowB.className = classB;
      rowB.innerHTML = `
        <span class="diff-gutter">${row.lineNumB !== null ? row.lineNumB : ""}</span>
        <span class="diff-sign">${row.type === "added" ? "+" : (row.type === "exact" ? "=" : (row.type === "renamed" ? "~" : (row.type === "modified" ? "•" : " ")))}</span>
        <span class="diff-code">${row.tokensB || (row.type === "deleted" ? "" : "&nbsp;")}</span>
      `;
      paneRight.appendChild(rowB);
    });

    container.appendChild(paneLeft);
    container.appendChild(paneRight);

    // Synchronized scroll
    if (syncScroll) {
      let isSyncingLeft = false;
      let isSyncingRight = false;

      paneLeft.addEventListener("scroll", () => {
        if (!isSyncingLeft) {
          isSyncingRight = true;
          paneRight.scrollTop = paneLeft.scrollTop;
          paneRight.scrollLeft = paneLeft.scrollLeft;
        }
        isSyncingLeft = false;
      });

      paneRight.addEventListener("scroll", () => {
        if (!isSyncingRight) {
          isSyncingLeft = true;
          paneLeft.scrollTop = paneRight.scrollTop;
          paneLeft.scrollLeft = paneRight.scrollLeft;
        }
        isSyncingRight = false;
      });
    }
  } else {
    // Unified mode
    container.className = "diff-viewport unified-mode";
    const pane = document.createElement("div");
    pane.className = "diff-pane";

    diffRows.forEach(row => {
      if (row.type === "deleted" || row.type === "modified") {
        const r = document.createElement("div");
        r.className = "diff-row diff-row-deleted";
        r.innerHTML = `
          <span class="diff-gutter">${row.lineNumA || ""}</span>
          <span class="diff-sign">-</span>
          <span class="diff-code">${row.tokensA}</span>
        `;
        pane.appendChild(r);
      }
      if (row.type === "added" || row.type === "modified") {
        const r = document.createElement("div");
        r.className = "diff-row diff-row-added";
        r.innerHTML = `
          <span class="diff-gutter">${row.lineNumB || ""}</span>
          <span class="diff-sign">+</span>
          <span class="diff-code">${row.tokensB}</span>
        `;
        pane.appendChild(r);
      }
      if (row.type === "exact" || row.type === "renamed") {
        const r = document.createElement("div");
        r.className = "diff-row " + (row.type === "exact" ? "diff-row-exact" : "diff-row-renamed");
        r.innerHTML = `
          <span class="diff-gutter">${row.lineNumA || row.lineNumB || ""}</span>
          <span class="diff-sign">${row.type === "exact" ? "=" : "~"}</span>
          <span class="diff-code">${row.tokensB || row.tokensA}</span>
        `;
        pane.appendChild(r);
      }
    });

    container.appendChild(pane);
  }
}

/* ============================================================== */
/* INTERACTIVE VISUAL ANALYTICS (CANVAS CHARTS)                   */
/* ============================================================== */

function drawDSUNetwork(canvas, clusters, pairs) {
  if (!canvas) return;
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  const width = (rect.width || 600);
  const height = (rect.height || 280);
  canvas.width = width * dpr;
  canvas.height = height * dpr;
  const ctx = canvas.getContext("2d");
  ctx.scale(dpr, dpr);

  ctx.clearRect(0, 0, width, height);

  const badge = document.getElementById("topology-count-badge");
  if (!clusters || clusters.length === 0) {
    if (badge) badge.textContent = "0 Clusters";
    ctx.fillStyle = "#64748b";
    ctx.font = "14px 'Plus Jakarta Sans', sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("No multi-file equivalence classes detected.", width / 2, height / 2);
    return;
  }

  let totalNodes = 0;
  clusters.forEach(c => totalNodes += 1 + (c.fragments?.length || 0));
  if (badge) badge.textContent = `${clusters.length} Clusters • ${totalNodes} Nodes`;

  const numClusters = clusters.length;

  for (let cIdx = 0; cIdx < numClusters; cIdx++) {
    const cluster = clusters[cIdx];
    const cx = numClusters === 1 ? width / 2 : (width / (numClusters + 1)) * (cIdx + 1);
    const cy = height / 2;

    const frags = cluster.fragments || [];
    const numFrags = frags.length;
    const orbitR = Math.min(80, Math.max(48, (height / 2) - 40));

    // Connectors & Leaf Nodes
    for (let fIdx = 0; fIdx < numFrags; fIdx++) {
      const angle = (2 * Math.PI / Math.max(1, numFrags)) * fIdx - (Math.PI / 2);
      const lx = cx + orbitR * Math.cos(angle);
      const ly = cy + orbitR * Math.sin(angle);

      // Connecting line
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(lx, ly);
      ctx.strokeStyle = "rgba(56, 189, 248, 0.32)";
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 4]);
      ctx.stroke();
      ctx.setLineDash([]);

      // Leaf file node
      ctx.beginPath();
      ctx.arc(lx, ly, 7, 0, 2 * Math.PI);
      ctx.fillStyle = "#10b981";
      ctx.shadowColor = "#10b981";
      ctx.shadowBlur = 8;
      ctx.fill();
      ctx.shadowBlur = 0;

      // Leaf label
      ctx.fillStyle = "#cbd5e1";
      ctx.font = "10px 'Fira Code', monospace";
      ctx.textAlign = lx >= cx ? "left" : "right";
      const shortPath = (frags[fIdx].file_path || "").split("/").pop() || "file";
      ctx.fillText(shortPath, lx + (lx >= cx ? 9 : -9), ly + 3);
    }

    // Cluster Center Root Node
    ctx.beginPath();
    ctx.arc(cx, cy, 18, 0, 2 * Math.PI);
    ctx.fillStyle = "#0284c7";
    ctx.shadowColor = "#38bdf8";
    ctx.shadowBlur = 14;
    ctx.fill();
    ctx.strokeStyle = "#38bdf8";
    ctx.lineWidth = 2.5;
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Cluster text
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 10px 'Outfit', sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(cluster.cluster_id || `C-${cIdx + 1}`, cx, cy + 3);
  }
}

function drawCloneTypeDoughnut(canvas, breakdown) {
  if (!canvas) return;
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  const width = rect.width || 220;
  const height = rect.height || 220;
  canvas.width = width * dpr;
  canvas.height = height * dpr;
  const ctx = canvas.getContext("2d");
  ctx.scale(dpr, dpr);

  ctx.clearRect(0, 0, width, height);

  const t1 = breakdown["Type-1"] || 0;
  const t2 = breakdown["Type-2"] || 0;
  const t3 = breakdown["Type-3"] || 0;
  const total = t1 + t2 + t3;

  const totalEl = document.getElementById("doughnut-center-total");
  if (totalEl) totalEl.textContent = total;

  const cx = width / 2;
  const cy = height / 2;
  const radius = Math.min(width, height) / 2 - 16;
  const lineWidth = 18;

  if (total === 0) {
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, 2 * Math.PI);
    ctx.strokeStyle = "rgba(255, 255, 255, 0.08)";
    ctx.lineWidth = lineWidth;
    ctx.stroke();
    return;
  }

  const slices = [
    { val: t1, color: "#10b981", glow: "rgba(16, 185, 129, 0.4)" },
    { val: t2, color: "#3b82f6", glow: "rgba(59, 130, 246, 0.4)" },
    { val: t3, color: "#f59e0b", glow: "rgba(245, 158, 11, 0.4)" }
  ];

  let startAngle = -Math.PI / 2;
  slices.forEach(slice => {
    if (slice.val <= 0) return;
    const sliceAngle = (slice.val / total) * 2 * Math.PI;
    const endAngle = startAngle + sliceAngle;

    ctx.beginPath();
    ctx.arc(cx, cy, radius, startAngle, endAngle);
    ctx.strokeStyle = slice.color;
    ctx.lineWidth = lineWidth;
    ctx.lineCap = "round";
    ctx.shadowColor = slice.glow;
    ctx.shadowBlur = 10;
    ctx.stroke();
    ctx.shadowBlur = 0;

    startAngle = endAngle;
  });
}

function drawDuplicationGauge(canvas, pct) {
  if (!canvas) return;
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  const width = rect.width || 220;
  const height = rect.height || 160;
  canvas.width = width * dpr;
  canvas.height = height * dpr;
  const ctx = canvas.getContext("2d");
  ctx.scale(dpr, dpr);

  ctx.clearRect(0, 0, width, height);

  const cx = width / 2;
  const cy = height - 25;
  const radius = Math.min(width / 2, height) - 25;
  const lineWidth = 16;

  // Background track arc (180 degrees from PI to 2*PI)
  ctx.beginPath();
  ctx.arc(cx, cy, radius, Math.PI, 2 * Math.PI);
  ctx.strokeStyle = "rgba(255, 255, 255, 0.08)";
  ctx.lineWidth = lineWidth;
  ctx.lineCap = "round";
  ctx.stroke();

  // Progress arc
  const clampedPct = Math.min(100, Math.max(0, pct));
  const progressAngle = Math.PI + (clampedPct / 100) * Math.PI;

  let strokeColor = "#10b981";
  let statusClass = "optimal";
  let statusText = "Optimal Health (<15%)";

  if (clampedPct > 30) {
    strokeColor = "#f43f5e";
    statusClass = "critical";
    statusText = "Critical Bloat (>30%)";
  } else if (clampedPct >= 15) {
    strokeColor = "#f59e0b";
    statusClass = "moderate";
    statusText = "Moderate Duplication (15-30%)";
  }

  const healthLabel = document.getElementById("gauge-health-label");
  if (healthLabel) {
    healthLabel.className = `health-label ${statusClass}`;
    healthLabel.textContent = statusText;
  }

  if (clampedPct > 0) {
    ctx.beginPath();
    ctx.arc(cx, cy, radius, Math.PI, progressAngle);
    ctx.strokeStyle = strokeColor;
    ctx.lineWidth = lineWidth;
    ctx.lineCap = "round";
    ctx.shadowColor = strokeColor;
    ctx.shadowBlur = 12;
    ctx.stroke();
    ctx.shadowBlur = 0;
  }

  // Value in center
  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 22px 'Outfit', sans-serif";
  ctx.textAlign = "center";
  ctx.fillText(`${clampedPct}%`, cx, cy - 14);

  ctx.fillStyle = "#94a3b8";
  ctx.font = "10px 'Plus Jakarta Sans', sans-serif";
  ctx.fillText("Codebase Duplication", cx, cy + 2);
}

/* ============================================================== */
/* EXPORT ENGINE (PDF / JSON / CSV) & TOAST SYSTEM                */
/* ============================================================== */

function exportScanToJson(data) {
  if (!data) return;
  const jsonStr = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonStr], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  const scanName = (data.scan_name || "clone_scan").replace(/[^a-zA-Z0-9_-]/g, "_");
  a.href = url;
  a.download = `clone_report_${scanName}_${data.id || Date.now()}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  showToast("Scan report exported to JSON file", "success");
}

function exportScanToCsv(data) {
  if (!data || !data.clone_pairs || data.clone_pairs.length === 0) {
    showToast("No clone pairs available to export to CSV.", "warning");
    return;
  }

  const headers = [
    "Pair ID",
    "Clone Type",
    "Similarity (%)",
    "Token Count",
    "Fragment A File",
    "Line A Start",
    "Line A End",
    "Fragment B File",
    "Line B Start",
    "Line B End",
    "Refactoring Suggestion"
  ];

  const rows = data.clone_pairs.map((p, idx) => {
    const fa = p.fragment_a || {};
    const fb = p.fragment_b || {};
    return [
      idx + 1,
      `"${(p.clone_type || '').replace(/"/g, '""')}"`,
      p.similarity || 0,
      p.token_count || 0,
      `"${(fa.file_path || '').replace(/"/g, '""')}"`,
      fa.start_line || 1,
      fa.end_line || 1,
      `"${(fb.file_path || '').replace(/"/g, '""')}"`,
      fb.start_line || 1,
      fb.end_line || 1,
      `"${(p.refactoring_suggestion || '').replace(/"/g, '""')}"`
    ].join(",");
  });

  const csvContent = [headers.join(","), ...rows].join("\n");
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  const scanName = (data.scan_name || "clone_pairs").replace(/[^a-zA-Z0-9_-]/g, "_");
  a.href = url;
  a.download = `clone_pairs_${scanName}_${data.id || Date.now()}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  showToast("Exported detected clone pairs to CSV spreadsheet", "success");
}

function printAuditReport(data) {
  if (!data) return;
  showToast("Preparing printable audit report...", "info");
  window.print();
}

function showToast(message, type = "info", duration = 3500) {
  const container = document.getElementById("toast-container");
  if (!container) return;
  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  let icon = "ℹ️";
  if (type === "success") icon = "✓";
  if (type === "warning") icon = "⚠️";
  toast.innerHTML = `
    <span style="font-weight:bold; font-size:1.05rem;">${icon}</span>
    <span style="flex:1;">${escapeHtml(message)}</span>
    <button class="btn-icon" style="font-size:0.8rem; padding:0 4px; cursor:pointer;" onclick="this.parentElement.remove()">✕</button>
  `;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateY(10px)";
    toast.style.transition = "all 0.3s ease";
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

function downloadTextFile(content, filename, mimeType = "text/html") {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
